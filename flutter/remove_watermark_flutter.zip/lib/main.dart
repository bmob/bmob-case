import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: '去抖音水印'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final TextEditingController _textController = TextEditingController(text: "https://v.douyin.com/DwCd21X/");
  bool _isSuccess = false;
  bool _requesting = false;
  String _video = "";
  late final String path;
  // late DownloaderUtils options;
  // late DownloaderCore core;
  late VideoPlayerController _controller;
  late String _fileHash;

  @override
  void initState() {
    super.initState();
    
    _controller = VideoPlayerController.network('');

    initPlatformState();
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
               LimitedBox(
                maxHeight: 200,
                child: TextField(
                  controller: _textController,
                  maxLines: null,
                  expands: true,
                  textAlignVertical: TextAlignVertical.top,
                  decoration: const InputDecoration(
                    hintText: '请输入抖音口令或者链接',
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.all(8),
                  ),
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _requesting ? null : () => action(),
                  child: const Text('一键去水印'),
                ),
              ),
              Visibility(
                visible: _isSuccess,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextButton.icon(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.check_circle_outline_rounded,
                        color: Colors.green,
                      ),
                      label: const Text('视频已经去除水印'),
                    ),
                    // const Placeholder(
                    //   fallbackHeight: 200,
                    // ),
                    GestureDetector(
                      onTap: () => playOrPath(),
                      child: Center(
                        child: SizedBox(
                          height: 200,
                          child: Stack(
                            alignment: AlignmentDirectional.center,
                            children: [
                              AspectRatio(
                                aspectRatio: _controller.value.aspectRatio,
                                child: VideoPlayer(_controller),
                              ),
                              GestureDetector(
                                onTap: () => playOrPath(),
                                child: Visibility(
                                  visible: !_controller.value.isPlaying,
                                  child:  const Icon(
                                    Icons.play_circle_outlined,
                                    size: 48,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => copy(),
                            child: const Text('复制链接'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => save(),
                            child: const Text('保存到相册'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void action() async {
    // String douyinUrl = "https://v.douyin.com/DwCd21X/";
    String douyinUrl = _textController.text;

    if (douyinUrl == '') {
      Fluttertoast.showToast(msg: '请输入抖音口令或链接');
      return;
    }

    String secretKey = "51e918580cb53429";
    String functionName = "douyin";
    String url =
        "http://cloud.codenow.cn/$secretKey/$functionName?url=$douyinUrl";

    setState(() {
      _requesting = true;
    });
    // 1.创建HttpClient对象
    final httpClient = HttpClient();
    // 2.构建请求的uri
    final uri = Uri.parse(url);
    // 3.构建请求
    final request = await httpClient.getUrl(uri);
    // 4.发送请求，必须
    final response = await request.close();
    setState(() {
      _requesting = false;
    });
    if (response.statusCode == HttpStatus.ok) {
      String ret = await response.transform(utf8.decoder).join();
      if (ret.startsWith("{") && ret.endsWith("}")) {
        // Map<String, dynamic> user = convert.jsonDecode(jsonString1);
        Map<String, dynamic> result = jsonDecode(ret);
        // 成功
        setState(() {
          _isSuccess = !_isSuccess;
          _video = result["video"];
          _fileHash = result["fileHash"];
        });
        _controller = VideoPlayerController.network(_video)
          ..initialize().then((_) {
            // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
            setState(() {});
          });
      } else {
        // 失败
        Fluttertoast.showToast(msg: ret);
      }
      debugPrint(ret);
      String z = ret.substring(ret.length - 1, ret.length);
      debugPrint(z);
    } else {
      debugPrint('${response.statusCode}');
    }
  }

  void copy() {
    Fluttertoast.showToast(msg: '复制链接成功');
    Clipboard.setData(ClipboardData(text: _video));
  }

  void playOrPath(){
    setState(() {
      _controller.value.isPlaying ? _controller.pause() : _controller.play();
    });
  }

  void save() {
    downloadFile();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          content: Row(
            children: const [
              CircularProgressIndicator(),
              SizedBox(width: 16),
              Text('保存中...'),
            ],
          ),
          actions: [
            TextButton(
              child: const Text("取消"),
              onPressed: () {
                Navigator.pop(context, 'Cancle');
              },
            ),
            TextButton(
              child: const Text("确定"),
              onPressed: () {
                Navigator.pop(context, "Ok");
              },
            )
          ],
        );
      },
    );
  }

  Future<void> initPlatformState() async {
    _setPath();
    if (!mounted) return;
  }

  void _setPath() async {
    Directory _path = await getTemporaryDirectory();
    // Directory? _path = await getExternalStorageDirectory();

    // String _localPath = _path.path + Platform.pathSeparator + 'Download';
    String localPath = "${_path.path}${Platform.pathSeparator}";

    final savedDir = Directory(localPath);
    bool hasExisted = await savedDir.exists();
    if (!hasExisted) {
      savedDir.create();
    }

    path = localPath;
  }

  Future<void> downloadFile() async {
    String fileName = '$_fileHash.mp4';
    String filePath = '$path$fileName';
    // final result = await ImageGallerySaver.saveFile(filePath);
    //     Navigator.pop(context, "Ok");
    //     Fluttertoast.showToast(msg: '保存到相册成功');

    var file = File(filePath);
    if (file.existsSync()) {
      file.delete();
    }

    print('文件存储路径: $filePath');
    // 下载文件
    await Dio().download(_video, filePath);
    // 保存到相册中
    await ImageGallerySaver.saveFile(filePath, name: fileName);
    Navigator.pop(context, "Ok");
    Fluttertoast.showToast(msg: '保存到相册成功');
  }
}
