package com.example.xhs_community_app.Fragment;


import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.xhs_community_app.Bean.Post;
import com.example.xhs_community_app.Bean.User;
import com.example.xhs_community_app.R;
import com.example.xhs_community_app.activity.Register;
import com.example.xhs_community_app.activity.Search;

import java.io.File;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobFile;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.QueryListener;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;
import cn.bmob.v3.listener.UploadFileListener;

public class FragmentFabu extends Fragment {
    //发布界面

    private ImageView publish_picture;
    private EditText publish_context,publish_title;
    private Button publish_btn;
    private Uri uri;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_fabu,container,false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initView();
    }

    private void initView() {
        publish_picture = getActivity().findViewById(R.id.edt_picture);
        publish_context = getActivity().findViewById(R.id.edt_context);
        publish_title = getActivity().findViewById(R.id.edt_title);
        publish_btn = getActivity().findViewById(R.id.publish_btn);
        publish_picture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, null);
                intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                startActivityForResult(intent, 2);
            }
        });
        publish_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final User user = BmobUser.getCurrentUser(User.class);
                Post post = new Post();
                if(publish_title.getText().toString().equals("")){
                    Toast.makeText(getActivity(),"标题不能为空",Toast.LENGTH_SHORT).show();
                }else if(publish_context.getText().toString().equals("")){
                    Toast.makeText(getActivity(),"内容不能为空",Toast.LENGTH_SHORT).show();
                }else if(uri==null){
                    Toast.makeText(getActivity(),"请选择发布的图片",Toast.LENGTH_SHORT).show();
                }else{
                    post.setTitle(publish_title.getText().toString());
                    post.setContent(publish_context.getText().toString());
                    post.setLikenum("0");
                    post.setUser(user);
                    String picPath = getPath(getActivity(),uri);
                    BmobFile bmobFile = new BmobFile(new File(picPath));
                    bmobFile.uploadblock(new UploadFileListener() {
                        @Override
                        public void done(BmobException e) {
                            if(e==null){
                                Toast.makeText(getActivity(), "上传图片成功"+bmobFile.getFileUrl(), Toast.LENGTH_SHORT).show();
                                post.setPicture(bmobFile);
                                post.save(new SaveListener<String>() {
                                    @Override
                                    public void done(String s, BmobException e) {   //发布成功，清除界面数据
                                        publish_title.setText("");
                                        publish_context.setText("");
                                        Resources r = getActivity().getResources(); //获取drawable文件夹中默认发布图片
                                        uri =  Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://"
                                                + r.getResourcePackageName (R.drawable.publish) + "/"
                                                + r.getResourceTypeName (R.drawable.publish) + "/"
                                                + r.getResourceEntryName (R.drawable.publish));
                                        publish_picture.setImageURI(uri);
                                    }
                                });
                            }else{
                                Toast.makeText(getActivity(), "上传图片失败"+e, Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onProgress(Integer value) {
                            // 返回的上传进度（百分比）
                        }
                    });
                }
            }
        });
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2) {
            // 从相册返回的数据
            if (data != null) {
                // 得到图片的全路径
                uri = data.getData();
                Log.e(this.getClass().getName(), "Uri:" + String.valueOf(uri));
            }else{
                Resources r = getActivity().getResources();
                uri =  Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://"
                        + r.getResourcePackageName (R.drawable.publish) + "/"
                        + r.getResourceTypeName (R.drawable.publish) + "/"
                        + r.getResourceEntryName (R.drawable.publish));
            }
            publish_picture.setImageURI(uri);
        }
    }

    //将获取的uri变成实际真实地址
    public String getPath(Context context, Uri uri) {
        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{split[1]};

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }
        return null;
    }
    private String getDataColumn(Context context, Uri uri, String selection,
                                 String[] selectionArgs) {
        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {column};

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }
    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

}
