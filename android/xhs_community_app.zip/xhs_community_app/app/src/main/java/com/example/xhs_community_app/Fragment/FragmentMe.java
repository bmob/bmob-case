package com.example.xhs_community_app.Fragment;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.xhs_community_app.Adapter.MeAdapter;
import com.example.xhs_community_app.Adapter.SearchAdapter;
import com.example.xhs_community_app.Bean.Post;
import com.example.xhs_community_app.Bean.User;
import com.example.xhs_community_app.MainActivity;
import com.example.xhs_community_app.R;
import com.example.xhs_community_app.activity.Collect;
import com.example.xhs_community_app.activity.InfoEdit;
import com.example.xhs_community_app.activity.Login;
import com.example.xhs_community_app.activity.Register;
import com.example.xhs_community_app.activity.Search;
import com.example.xhs_community_app.activity.Set;
import com.example.xhs_community_app.util.RoundImageView;

import java.util.List;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobFile;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.DownloadFileListener;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.QueryListener;

public class FragmentMe extends Fragment {

    private TextView username,nickname,school,post_num,like_num,collect_num;
    private Button edit;
    private LinearLayout collect;
    private ImageView set;
    private RoundImageView photo;
    List<Post> data;
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private MeAdapter meAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_me,container,false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        initView();

        Bmob.initialize(getActivity(),"6640f9b56fa28570b0915db0e8dcb00d");

        Refresh();
        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_green_light,android.R.color.holo_red_light,android.R.color.holo_blue_light);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                //刷新
                Refresh();
            }
        });

        set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Set.class);
                startActivity(intent);
            }
        });
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), InfoEdit.class);
                startActivity(intent);
            }
        });
        collect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Collect.class);
                startActivity(intent);
            }
        });
    }

    private void getMyinfo(){
        BmobUser bu = BmobUser.getCurrentUser(BmobUser.class);
        String Id = bu.getObjectId();
        BmobQuery<User> bmobQuery = new BmobQuery<>();
        bmobQuery.getObject(Id, new QueryListener<User>() {
            @Override
            public void done(User user, BmobException e) {
                if(e==null){
                    String xhs_num = "小红书号："+user.getUsername();
                    username.setText(xhs_num);
                    nickname.setText(user.getNickname());
                    school.setText(user.getSchool());
                    collect_num.setText(user.getCollectnum());
                    BmobFile img = user.getPhoto();   //下载图片
                    img.download(new DownloadFileListener() {
                        @Override
                        public void done(String s, BmobException e) {
                            photo.setImageBitmap(BitmapFactory.decodeFile(s));
                        }

                        @Override
                        public void onProgress(Integer integer, long l) {

                        }
                    });
                }else{
                    Toast.makeText(getActivity(), "加载失败", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void Refresh() {
        getMyinfo();
        User user = BmobUser.getCurrentUser(User.class);
        BmobQuery<Post> Po = new BmobQuery<Post>();     //查询
        Po.include("user");
        Po.addWhereEqualTo("user",user);
        Po.order("-createdAt");     //显示顺序，按照创建时间顺序
        Po.setLimit(1000);          //显示限制
        Po.findObjects(new FindListener<Post>() {
            @Override
            public void done(List<Post> list, BmobException e) {
                swipeRefreshLayout.setRefreshing(false);
                if(e==null){
                    data=list;
                    Integer num = list.size();
                    post_num.setText(num.toString());
                    if(list.size()>0){
                        meAdapter = new MeAdapter(getActivity(),data);
                        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
                        recyclerView.setLayoutManager(layoutManager);
                        layoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_NONE);
                        recyclerView.setAdapter(meAdapter);
                        int j;
                        Integer sum_like=0;
                        for(j=0;j<list.size();j++){
                            sum_like = sum_like + Integer.valueOf(list.get(j).getLikenum());
                        }
                        like_num.setText(sum_like.toString());
                    }else{
                        Toast.makeText(getActivity(),"还没有发布内容",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    swipeRefreshLayout.setRefreshing(false);
                }
            }
        });
    }



    @Override
    public void onResume() {
        super.onResume();
        getMyinfo();//刷新数据
    }



    private void initView(){
        username = getActivity().findViewById(R.id.me_username);
        nickname = getActivity().findViewById(R.id.me_nickname);
        school = getActivity().findViewById(R.id.me_school);
        set = getActivity().findViewById(R.id.me_set_btn);
        post_num = getActivity().findViewById(R.id.me_post_num);
        collect_num = getActivity().findViewById(R.id.me_collect_num);
        like_num = getActivity().findViewById(R.id.me_like_num);
        edit = getActivity().findViewById(R.id.me_edit_btn);
        photo = getActivity().findViewById(R.id.me_userphoto);
        collect = getActivity().findViewById(R.id.me_collect);
        recyclerView = getActivity().findViewById(R.id.me_recyclerview);
        swipeRefreshLayout = getActivity().findViewById(R.id.me_swipe);
    }
}
