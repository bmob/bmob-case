package com.example.xhs_community_app.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.xhs_community_app.Adapter.CollectAdapter;
import com.example.xhs_community_app.Adapter.SearchAdapter;
import com.example.xhs_community_app.Bean.Post;
import com.example.xhs_community_app.Bean.User;
import com.example.xhs_community_app.R;

import java.util.List;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobPointer;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

public class Collect extends AppCompatActivity {

    private Button back;
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;
    List<Post> data;
    private CollectAdapter collectAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collect);

        initView();
        Bmob.initialize(this,"6640f9b56fa28570b0915db0e8dcb00d");

        //初始化刷新
        Refresh();
        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_green_light,android.R.color.holo_red_light,android.R.color.holo_blue_light);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                //刷新
                Refresh();
            }
        });
    }

    private void Refresh() {
        User user = BmobUser.getCurrentUser(User.class);
        BmobQuery<Post> Po = new BmobQuery<Post>();     //查询
        Po.include("user");
        Po.addWhereEqualTo("relation", user);
        Po.order("-createdAt");     //显示顺序，按照创建时间顺序
        Po.setLimit(1000);          //显示限制
        Po.findObjects(new FindListener<Post>() {
            @Override
            public void done(List<Post> list, BmobException e) {
                swipeRefreshLayout.setRefreshing(false);
                if(e==null){
                    data=list;
                    if(list.size()>0){
                        collectAdapter = new CollectAdapter(Collect.this,data);
                        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
                        recyclerView.setLayoutManager(layoutManager);
                        layoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_NONE);
                        recyclerView.setAdapter(collectAdapter);
                    }else{
                        Toast.makeText(Collect.this,"还没有收藏笔记",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    swipeRefreshLayout.setRefreshing(false);
                }
            }
        });
    }

    private void initView() {
        recyclerView = findViewById(R.id.collect_recycleview);
        swipeRefreshLayout = findViewById(R.id.collect_swipe);
        back = findViewById(R.id.collect_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}