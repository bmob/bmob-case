package com.example.xhs_community_app.activity;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.xhs_community_app.Bean.User;
import com.example.xhs_community_app.R;
import com.example.xhs_community_app.util.RoundImageView;

import java.io.File;

import cn.bmob.v3.datatype.BmobFile;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UploadFileListener;

public class Register extends AppCompatActivity {

    private EditText username,password,password2,nickname,phone_num;
    private Button register;
    public RoundImageView photo;
    private Uri uri,init_uri;
    String pwd,pwd2;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        username = findViewById(R.id.etUsername);
        password = findViewById(R.id.etPassword);
        password2 = findViewById(R.id.etPassword2);
        nickname = findViewById(R.id.etnickname);
        register = findViewById(R.id.btnRegister);
        photo = findViewById(R.id.register_photo);
        phone_num = findViewById(R.id.etPhone_num);

        photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, null);
                intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                startActivityForResult(intent, 2);
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pwd=password.getText().toString().trim();
                pwd2=password2.getText().toString().trim();
                if(username.getText().toString().equals("")){
                    Toast.makeText(Register.this,"用户名不能为空",Toast.LENGTH_SHORT).show();
                }else if(phone_num.getText().toString().equals("")){
                    Toast.makeText(Register.this,"请输入手机号",Toast.LENGTH_SHORT).show();
                } else if(password.getText().toString().equals("")){
                    Toast.makeText(Register.this,"请输入密码",Toast.LENGTH_SHORT).show();
                }else if(password2.getText().toString().equals("")){
                    Toast.makeText(Register.this,"请再次输入密码",Toast.LENGTH_SHORT).show();
                }else if(!pwd2.equalsIgnoreCase(pwd)){
                    Toast.makeText(Register.this,"两次输入的密码不一致",Toast.LENGTH_SHORT).show();
                }else if(uri==null) {
                    Toast.makeText(Register.this,"请先设置头像",Toast.LENGTH_SHORT).show();
                }else {
                    final User user = new User();
                    user.setUsername(username.getText().toString().trim());
                    user.setPassword(password.getText().toString().trim());
                    user.setNickname(nickname.getText().toString().trim());
                    user.setMobilePhoneNumber(phone_num.getText().toString().trim());
                    user.setSite("浙江");
                    user.setCollectnum("0");
                    user.setBirth("2000-01-01");
                    user.setSex("男");
                    user.setSchool("中国计量大学");
                    String picPath = getPath(Register.this,uri);
                    BmobFile bmobFile = new BmobFile(new File(picPath));
                    bmobFile.uploadblock(new UploadFileListener() {
                        @Override
                        public void done(BmobException e) {
                            if (e == null) {
                                user.setPhoto(bmobFile);
                                Toast.makeText(Register.this, "上传成功"+bmobFile.getFileUrl(), Toast.LENGTH_SHORT).show();
                                user.signUp(new SaveListener<User>() {
                                    @Override
                                    public void done(User user, BmobException e) {
                                        if (e == null) {
                                            Toast.makeText(Register.this, "注册成功", Toast.LENGTH_SHORT).show();
                                            finish();
                                        } else {
                                            Toast.makeText(Register.this, "注册失败" + e, Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                            }
                            else{
                                Toast.makeText(Register.this, "上传失败"+e, Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onProgress(Integer value) {
                            // 返回的上传进度（百分比）
                        }
                    });
                }
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2) {
            // 从相册返回的数据
            if (data != null) {
                // 得到图片的全路径
                uri = data.getData();
                Log.e(this.getClass().getName(), "Uri:" + String.valueOf(uri));
                photo.setImageURI(uri);
            }else{
                Resources r = Register.this.getResources();
                init_uri =  Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://"
                        + r.getResourcePackageName(R.drawable.me2) + "/"
                        + r.getResourceTypeName(R.drawable.me2) + "/"
                        + r.getResourceEntryName(R.drawable.me2));
                photo.setImageURI(init_uri);
            }
        }
    }

    //将获取的uri变成实际真实地址
    public String getPath(Context context, Uri uri) {
        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{split[1]};

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }
        return null;
    }
    private String getDataColumn(Context context, Uri uri, String selection,
                                 String[] selectionArgs) {
        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {column};

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }
    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }
}