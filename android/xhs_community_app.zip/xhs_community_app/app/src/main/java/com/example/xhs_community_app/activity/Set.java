package com.example.xhs_community_app.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.xhs_community_app.R;

import cn.bmob.v3.BmobUser;

public class Set extends AppCompatActivity {

    private Button back,back_to_me;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set);

        back = findViewById(R.id.set_back);
        back_to_me = findViewById(R.id.set_back_btn);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {    //退出登录并跳转回登录界面
                BmobUser.logOut();
                startActivity(new Intent(Set.this,Login.class));
                finish();
            }
        });
        back_to_me.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}