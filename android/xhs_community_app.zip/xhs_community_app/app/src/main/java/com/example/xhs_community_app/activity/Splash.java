package com.example.xhs_community_app.activity;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.xhs_community_app.MainActivity;
import com.example.xhs_community_app.R;

import java.util.Timer;
import java.util.TimerTask;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobUser;

//欢迎界面
public class Splash extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Timer timer = new Timer();  //延时跳转
        timer.schedule(timetast,2000);

        Bmob.initialize(this,"6640f9b56fa28570b0915db0e8dcb00d");
    }
    TimerTask timetast = new TimerTask() {
        @Override
        public void run() {     //如果已登录跳到主界面，未登录则跳转到登录界面
            BmobUser bmobUser = BmobUser.getCurrentUser(BmobUser.class);
            if(bmobUser!=null){
                startActivity(new Intent(Splash.this,MainActivity.class));
                finish();
            }else{
                startActivity(new Intent(Splash.this,Login.class));
                finish();
            }
        }
    };
}
