package com.example.xhs_community_app.Adapter;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.xhs_community_app.Bean.Post;
import com.example.xhs_community_app.Bean.User;
import com.example.xhs_community_app.R;
import com.example.xhs_community_app.activity.Login;
import com.example.xhs_community_app.activity.Recive;
import com.example.xhs_community_app.util.RoundImageView;

import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobFile;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.DownloadFileListener;
import cn.bmob.v3.listener.FindListener;

public class CommunityAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private List<Post> data;
    //普通类型
    private final int N_TYPE = 0;
    private final int F_TYPE = 1;

    private int Max_num = 15;   //预加载15条

    private Boolean isfootview = true;//是否有footview

    public CommunityAdapter(Context context, List<Post> data){
        this.context=context;
        this.data=data;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.ord_item,viewGroup,false);
        View footview = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.foot_item,viewGroup,false);
        if(i==F_TYPE){
            return new RecyclerViewHolder(footview,F_TYPE);
        }else{
            return new RecyclerViewHolder(view,N_TYPE);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if(isfootview && (getItemViewType(i))==F_TYPE){
            //底部加载提示
            final RecyclerViewHolder recyclerViewHolder = (RecyclerViewHolder) viewHolder;
            recyclerViewHolder.Loading.setText("加载中...");
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Max_num += 8;   //每次刷新增加8条
                    notifyDataSetChanged();
                }
            },2000);
        }else{
            //这是ord_item的内容
            final RecyclerViewHolder recyclerViewHolder = (RecyclerViewHolder) viewHolder;
            Post post = data.get(i);

            BmobFile img = post.getPicture();   //下载图片
            img.download(new DownloadFileListener() {
                @Override
                public void done(String s, BmobException e) {
                    recyclerViewHolder.picture.setImageBitmap(BitmapFactory.decodeFile(s));
                }

                @Override
                public void onProgress(Integer integer, long l) {

                }
            });
            BmobFile uphoto = post.getUser().getPhoto();   //下载图片
            uphoto.download(new DownloadFileListener() {
                @Override
                public void done(String s, BmobException e) {
                    recyclerViewHolder.photo.setImageBitmap(BitmapFactory.decodeFile(s));
                }

                @Override
                public void onProgress(Integer integer, long l) {

                }
            });
            recyclerViewHolder.like_num.setText(post.getLikenum());
            recyclerViewHolder.title.setText(post.getTitle());
            recyclerViewHolder.nickname.setText(post.getUser().getNickname());
            recyclerViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = recyclerViewHolder.getBindingAdapterPosition();
                    if(BmobUser.getCurrentUser(BmobUser.class)!=null){  //判断是否是一个用户点击
                        Intent in = new Intent(context, Recive.class);
                        in.putExtra("id",data.get(position).getObjectId());
                        context.startActivity(in);
                    }else{
                        Toast.makeText(context, "请登录", Toast.LENGTH_SHORT).show();
                        context.startActivity(new Intent(context, Login.class));
                    }
                }
            });
        }

    }

    @Override
    public int getItemViewType(int position) {
        if(position == Max_num-1){
            return F_TYPE;  //底部
        }else{
            return N_TYPE;
        }
    }

    @Override
    public int getItemCount() {
        if(data.size() < Max_num){
            return data.size();
        }
        return Max_num;
    }

    private class RecyclerViewHolder extends RecyclerView.ViewHolder {

        public TextView nickname,title,like_num;
        public TextView Loading;
        public ImageView picture,like;
        public RoundImageView photo;

        public RecyclerViewHolder(View itemview, int view_type) {
            super(itemview);
            if(view_type==N_TYPE){
                nickname = itemview.findViewById(R.id.tv_nickname);
                title = itemview.findViewById(R.id.title_view);
                picture = itemview.findViewById(R.id.imageview);
                photo = itemview.findViewById(R.id.photo_itemview);
                like = itemview.findViewById(R.id.like);
                like_num = itemview.findViewById(R.id.like_num);
            }else if(view_type == F_TYPE){
                Loading = itemview.findViewById(R.id.footText);
            }
        }
    }
}
