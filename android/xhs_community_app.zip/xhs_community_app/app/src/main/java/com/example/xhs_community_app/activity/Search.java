package com.example.xhs_community_app.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.xhs_community_app.Adapter.CommunityAdapter;
import com.example.xhs_community_app.Adapter.SearchAdapter;
import com.example.xhs_community_app.Bean.Post;
import com.example.xhs_community_app.MainActivity;
import com.example.xhs_community_app.R;

import java.util.List;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

public class Search extends AppCompatActivity {

    private Button search_back,search_btn;
    private EditText search_text;
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;
    List<Post> data;
    private SearchAdapter searchAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        initView();
        Bmob.initialize(this,"6640f9b56fa28570b0915db0e8dcb00d");


        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_green_light,android.R.color.holo_red_light,android.R.color.holo_blue_light);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                //刷新
                Refresh();
            }
        });
    }

    private void Refresh() {
        BmobQuery<Post> Po = new BmobQuery<Post>();//查询
        Po.include("user");
        Po.addWhereContains("title",search_text.getText().toString());
        Po.order("-createdAt");     //显示顺序，按照创建时间顺序
        Po.setLimit(1000);          //显示限制
        Po.findObjects(new FindListener<Post>() {
            @Override
            public void done(List<Post> list, BmobException e) {
                swipeRefreshLayout.setRefreshing(false);
                if(e==null){
                    data=list;
                    if(list.size()>0){
                        searchAdapter = new SearchAdapter(Search.this,data);
                        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
                        recyclerView.setLayoutManager(layoutManager);
                        layoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_NONE);
                        recyclerView.setAdapter(searchAdapter);
                    }else{
                        Toast.makeText(Search.this,"没有找到相关内容，换个词试试吧",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    swipeRefreshLayout.setRefreshing(false);
                }
            }
        });
    }

    private void initView() {
        recyclerView = findViewById(R.id.search_recycleview);
        swipeRefreshLayout = findViewById(R.id.search_swipe);
        search_back = findViewById(R.id.search_back_btn);
        search_text = findViewById(R.id.search_edit);
        search_btn = findViewById(R.id.btn_search);
        search_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Refresh();
            }
        });
        search_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}