package com.example.xhs_community_app.Adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.xhs_community_app.Bean.Comment;
import com.example.xhs_community_app.Bean.Post;
import com.example.xhs_community_app.Bean.User;
import com.example.xhs_community_app.R;
import com.example.xhs_community_app.activity.Login;
import com.example.xhs_community_app.activity.Recive;
import com.example.xhs_community_app.util.RoundImageView;

import java.util.List;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobFile;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.DownloadFileListener;
import cn.bmob.v3.listener.UpdateListener;

public class CommentAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private Context context;
    private List<Comment> data;
    //普通类型
    private final int N_TYPE = 0;
    private final int F_TYPE = 1;
    User user = BmobUser.getCurrentUser(User.class);
    private int Max_num = 15;   //预加载15条

    private Boolean isfootview = true;//是否有footview

    public CommentAdapter(Context context, List<Comment> data){
        this.context=context;
        this.data=data;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.comment_item,viewGroup,false);
        View footview = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.foot_item,viewGroup,false);
        if(i==F_TYPE){
            return new CommentAdapter.RecyclerViewHolder(footview,F_TYPE);
        }else{
            return new CommentAdapter.RecyclerViewHolder(view,N_TYPE);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if(isfootview && (getItemViewType(i))==F_TYPE){
            //底部加载提示
            final CommentAdapter.RecyclerViewHolder recyclerViewHolder = (CommentAdapter.RecyclerViewHolder) viewHolder;
            recyclerViewHolder.Loading.setText("加载中...");
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Max_num += 8;   //每次刷新增加8条
                    notifyDataSetChanged();
                }
            },2000);
        }else{
            //这是ord_item的内容
            final CommentAdapter.RecyclerViewHolder recyclerViewHolder = (CommentAdapter.RecyclerViewHolder) viewHolder;
            Comment comment = data.get(i);
            if(comment.getUser().getObjectId().equals(user.getObjectId())){
                recyclerViewHolder.delete_comment.setVisibility(View.VISIBLE);
            }
            BmobFile uphoto = comment.getUser().getPhoto();   //下载图片
            uphoto.download(new DownloadFileListener() {
                @Override
                public void done(String s, BmobException e) {
                    recyclerViewHolder.comment_photo.setImageBitmap(BitmapFactory.decodeFile(s));
                }

                @Override
                public void onProgress(Integer integer, long l) {

                }
            });
            recyclerViewHolder.comment_text.setText(comment.getContent());
            recyclerViewHolder.comment_time.setText(comment.getCreatedAt());
            recyclerViewHolder.comment_name.setText(comment.getUser().getNickname());
            recyclerViewHolder.delete_comment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    comment.delete(new UpdateListener() {
                        @Override
                        public void done(BmobException e) {

                        }
                    });
                }
            });
        }

    }

    @Override
    public int getItemViewType(int position) {
        if(position == Max_num-1){
            return F_TYPE;  //底部
        }else{
            return N_TYPE;
        }
    }

    @Override
    public int getItemCount() {
        if(data.size() < Max_num){
            return data.size();
        }
        return Max_num;
    }

    private class RecyclerViewHolder extends RecyclerView.ViewHolder {

        public TextView comment_name,comment_text,comment_time;
        public TextView Loading;
        public RoundImageView comment_photo;
        public ImageView delete_comment;

        public RecyclerViewHolder(View itemview, int view_type) {
            super(itemview);
            if(view_type==N_TYPE){
                comment_name = itemview.findViewById(R.id.comment_name);
                comment_text = itemview.findViewById(R.id.comment_text);
                comment_photo = itemview.findViewById(R.id.comment_photo);
                comment_time = itemview.findViewById(R.id.comment_time);
                delete_comment = itemview.findViewById(R.id.delete_comment);
            }else if(view_type == F_TYPE){
                Loading = itemview.findViewById(R.id.footText);
            }
        }
    }
}
