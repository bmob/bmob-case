package com.example.xhs_community_app.activity;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.xhs_community_app.Adapter.CollectAdapter;
import com.example.xhs_community_app.Adapter.CommentAdapter;
import com.example.xhs_community_app.Adapter.CommunityAdapter;
import com.example.xhs_community_app.Bean.Comment;
import com.example.xhs_community_app.Bean.Post;
import com.example.xhs_community_app.Bean.User;
import com.example.xhs_community_app.R;

import java.util.List;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobFile;
import cn.bmob.v3.datatype.BmobPointer;
import cn.bmob.v3.datatype.BmobRelation;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.DownloadFileListener;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.QueryListener;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;

public class Recive extends AppCompatActivity {

    private TextView title,content,nickname,time,school,comment_num;
    private EditText comment_edt;
    private ImageView tupian,photo,like;
    private Button back,edit,delete,comment_btn;
    private ImageView collect;
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;
    List<Comment> data;
    private CommentAdapter commentAdapter;
    private String init_like;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recive);

        initView();
        initData();
        Bmob.initialize(Recive.this,"6640f9b56fa28570b0915db0e8dcb00d");

        getIsRelated();
        getLikeIsRelated();

        //初始化刷新
        Refresh();
        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_green_light,android.R.color.holo_red_light,android.R.color.holo_blue_light);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                //刷新
                Refresh();
            }
        });

    }

    private void Refresh() {
        User user = BmobUser.getCurrentUser(User.class);
        BmobQuery<Comment> cq = new BmobQuery<Comment>();     //查询
        cq.include("user,post");
        Post post = new Post();
        Intent in = getIntent();
        String id = in.getStringExtra("id");
        post.setObjectId(id);
        cq.addWhereEqualTo("post",new BmobPointer(post));
        cq.order("-createdAt");     //显示顺序，按照创建时间顺序
        cq.setLimit(1000);          //显示限制
        cq.findObjects(new FindListener<Comment>() {
            @Override
            public void done(List<Comment> list, BmobException e) {
                swipeRefreshLayout.setRefreshing(false);
                if(e==null){
                    data=list;
                    String c_num = "共"+list.size()+"条评论";
                    comment_num.setText(c_num);
                    if(list.size()>0){
                        commentAdapter = new CommentAdapter(Recive.this,data);
                        recyclerView.setLayoutManager(new LinearLayoutManager(Recive.this));
                        recyclerView.setAdapter(commentAdapter);
                    }else{
                        Toast.makeText(Recive.this,"暂无评论",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    swipeRefreshLayout.setRefreshing(false);
                }
            }
        });
    }

    private void getIsRelated(){
        Intent in = getIntent();
        String id = in.getStringExtra("id");
        User user = BmobUser.getCurrentUser(User.class);
        BmobQuery<Post> bmobQuery = new BmobQuery<>();
        bmobQuery.addWhereEqualTo("relation", user);
        bmobQuery.order("-createdAt");     //显示顺序，按照创建时间顺序
        bmobQuery.setLimit(1000);          //显示限制
        bmobQuery.findObjects(new FindListener<Post>() {
            @Override
            public void done(List<Post> list, BmobException e) {
                if(list.size()>0) {
                    int flag = 0;
                    int j;
                    for (j = 0; j < list.size(); j++) {
                        if (list.get(j).getObjectId().equals(id)) {
                            flag = 1;
                            break;
                        }
                    }
                    if(flag==1){
                        collect.setImageResource(R.drawable.collect1);
                    }
                }
            }
        });
    }
    private void getLikeIsRelated(){
        Intent in = getIntent();
        String id = in.getStringExtra("id");
        User user = BmobUser.getCurrentUser(User.class);
        BmobQuery<Post> bmobQuery = new BmobQuery<>();
        bmobQuery.addWhereEqualTo("relation2", user);
        bmobQuery.order("-createdAt");     //显示顺序，按照创建时间顺序
        bmobQuery.setLimit(1000);          //显示限制
        bmobQuery.findObjects(new FindListener<Post>() {
            @Override
            public void done(List<Post> list, BmobException e) {
                if(list.size()>0) {
                    int flag = 0;
                    int j;
                    for (j = 0; j < list.size(); j++) {
                        if (list.get(j).getObjectId().equals(id)) {
                            flag = 1;
                            break;
                        }
                    }
                    if(flag==1){
                        like.setImageResource(R.drawable.like1);
                    }
                }
            }
        });
    }

    private void initData() {
        Intent in = getIntent();
        String id = in.getStringExtra("id");
        Post po = new Post();

        BmobQuery<Post> query = new BmobQuery<>();
        query.include("user");
        query.getObject(id, new QueryListener<Post>() {
            @Override
            public void done(Post post, BmobException e) {
                if(e==null){
                    final BmobUser user = BmobUser.getCurrentUser(User.class);
                    if(post.getUser().getUsername().equals(user.getUsername())){
                        edit.setVisibility(View.VISIBLE);
                        delete.setVisibility(View.VISIBLE);
                    }else{
                        collect.setVisibility(View.VISIBLE);
                    }
                    init_like = post.getLikenum();
                    nickname.setText(post.getUser().getNickname());
                    content.setText(post.getContent());
                    school.setText(post.getUser().getSchool());
                    title.setText(post.getTitle());
                    time.setText(post.getCreatedAt());
                    BmobFile img = post.getPicture();   //下载图片
                    img.download(new DownloadFileListener() {
                        @Override
                        public void done(String s, BmobException e) {
                            tupian.setImageBitmap(BitmapFactory.decodeFile(s));
                        }

                        @Override
                        public void onProgress(Integer integer, long l) {

                        }
                    });
                    BmobFile uphoto = post.getUser().getPhoto();   //下载图片
                    uphoto.download(new DownloadFileListener() {
                        @Override
                        public void done(String s, BmobException e) {
                            photo.setImageBitmap(BitmapFactory.decodeFile(s));
                        }

                        @Override
                        public void onProgress(Integer integer, long l) {

                        }
                    });
                }else{
                    Toast.makeText(Recive.this, "获取失败", Toast.LENGTH_SHORT).show();
                }
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                po.setObjectId(id);
                finish();
                po.delete(new UpdateListener() {
                    @Override
                    public void done(BmobException e) {
                        if(e==null){
                            Toast.makeText(Recive.this, "删除成功", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(Recive.this, "删除失败"+e, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                BmobQuery<Comment> cq = new BmobQuery<Comment>();     //查询
                cq.include("user,post");
                po.setObjectId(id);
                cq.addWhereEqualTo("post",new BmobPointer(po));
                cq.order("-createdAt");     //显示顺序，按照创建时间顺序
                cq.setLimit(1000);          //显示限制
                cq.findObjects(new FindListener<Comment>() {
                    @Override
                    public void done(List<Comment> list, BmobException e) {
                        if(e==null){
                            data=list;
                            if(list.size()>0){
                                int j;
                                for(j=0;j<list.size();j++){
                                    list.get(j).delete(new UpdateListener() {
                                        @Override
                                        public void done(BmobException e) {

                                        }
                                    });
                                }
                            }else{
                            }
                        }
                    }
                });
            }
        });
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Recive.this, Edit.class);
                intent.putExtra("id",id);
                startActivity(intent);
                finish();
            }
        });
        collect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final User user = BmobUser.getCurrentUser(User.class);
                BmobQuery<Post> bmobQuery = new BmobQuery<>();
                bmobQuery.addWhereEqualTo("relation", user);
                bmobQuery.order("-createdAt");     //显示顺序，按照创建时间顺序
                bmobQuery.setLimit(1000);          //显示限制
                bmobQuery.findObjects(new FindListener<Post>() {
                    @Override
                    public void done(List<Post> list, BmobException e) {
                        bmobQuery.getObject(id, new QueryListener<Post>() {
                            @Override
                            public void done(Post post, BmobException e) {
                                BmobQuery<User> query = new BmobQuery<>();
                                if(list.size()>0){
                                    int flag=0;
                                    int j;
                                    for(j=0;j<list.size();j++){
                                        if(list.get(j).getObjectId().equals(id)){
                                            flag=1;
                                            break;
                                        }
                                    }
                                    if(flag==1){
                                        //已被收藏
                                        Post po = new Post();
                                        po.setObjectId(id);
                                        BmobRelation relation = new BmobRelation();
                                        relation.remove(user);
                                        po.setRelation(relation);
                                        po.update(new UpdateListener() {
                                            @Override
                                            public void done(BmobException e) {
                                                if(e==null){
                                                    Toast.makeText(Recive.this,"已取消收藏",Toast.LENGTH_SHORT).show();
                                                    collect.setImageResource(R.drawable.collect2);
                                                    Integer num = Integer.valueOf(user.getCollectnum())-1;
                                                    user.setCollectnum(num.toString());
                                                    user.update(new UpdateListener() {
                                                        @Override
                                                        public void done(BmobException e) {
                                                            if(e==null){
                                                            }
                                                        }
                                                    });
                                                }else{
                                                    Toast.makeText(Recive.this,"取消收藏失败",Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        });
                                    }
                                    else if(flag == 0){
                                        //未被收藏
                                        Post po = new Post();
                                        po.setObjectId(id);
                                        BmobRelation relation = new BmobRelation();
                                        relation.add(user);
                                        po.setRelation(relation);
                                        po.update(new UpdateListener() {
                                            @Override
                                            public void done(BmobException e) {
                                                if(e==null){
                                                    Toast.makeText(Recive.this,"收藏成功",Toast.LENGTH_SHORT).show();
                                                    collect.setImageResource(R.drawable.collect1);
                                                    Integer num = Integer.valueOf(user.getCollectnum())+1;
                                                    user.setCollectnum(num.toString());
                                                    user.update(new UpdateListener() {
                                                        @Override
                                                        public void done(BmobException e) {
                                                            if(e==null){
                                                            }
                                                        }
                                                    });
                                                }else{
                                                    Toast.makeText(Recive.this,"收藏失败",Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        });
                                    }
                                }else if(list.size()==0){
                                    //未被收藏
                                    Post po = new Post();
                                    po.setObjectId(id);
                                    BmobRelation relation = new BmobRelation();
                                    relation.add(user);
                                    po.setRelation(relation);
                                    po.update(new UpdateListener() {
                                        @Override
                                        public void done(BmobException e) {
                                            if(e==null){
                                                Toast.makeText(Recive.this,"收藏成功",Toast.LENGTH_SHORT).show();
                                                collect.setImageResource(R.drawable.collect1);
                                                Integer num = Integer.valueOf(user.getCollectnum())+1;
                                                user.setCollectnum(num.toString());
                                                user.update(new UpdateListener() {
                                                    @Override
                                                    public void done(BmobException e) {
                                                        if(e==null){
                                                        }
                                                    }
                                                });
                                            }else{
                                                Toast.makeText(Recive.this,"收藏失败",Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                                }
                            }
                        });
                    }
                });
            }
        });
        like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final User user = BmobUser.getCurrentUser(User.class);
                BmobQuery<Post> bmobQuery = new BmobQuery<>();
                bmobQuery.addWhereEqualTo("relation2", user);
                bmobQuery.order("-createdAt");     //显示顺序，按照创建时间顺序
                bmobQuery.setLimit(1000);          //显示限制
                bmobQuery.findObjects(new FindListener<Post>() {
                    @Override
                    public void done(List<Post> list, BmobException e) {
                        bmobQuery.getObject(id, new QueryListener<Post>() {
                            @Override
                            public void done(Post post, BmobException e) {
                                BmobQuery<User> query = new BmobQuery<>();
                                if(list.size()>0){
                                    int flag=0;
                                    int j;
                                    for(j=0;j<list.size();j++){
                                        if(list.get(j).getObjectId().equals(id)){
                                            flag=1;
                                            break;
                                        }
                                    }
                                    if(flag==1){
                                        //已点赞
                                        Post po = new Post();
                                        po.setObjectId(id);
                                        BmobRelation relation2 = new BmobRelation();
                                        relation2.remove(user);
                                        po.setRelation2(relation2);
                                        Integer like_num = Integer.valueOf(init_like)-1;
                                        po.setLikenum(like_num.toString());
                                        po.update(new UpdateListener() {
                                            @Override
                                            public void done(BmobException e) {
                                                if(e==null){
                                                    Toast.makeText(Recive.this,"已取消点赞",Toast.LENGTH_SHORT).show();
                                                    like.setImageResource(R.drawable.like);
                                                }else{
                                                    Toast.makeText(Recive.this,"取消点赞失败",Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        });
                                    }
                                    else if(flag == 0){
                                        //未点赞
                                        Post po = new Post();
                                        po.setObjectId(id);
                                        BmobRelation relation2 = new BmobRelation();
                                        relation2.add(user);
                                        po.setRelation2(relation2);
                                        Integer like_num = Integer.valueOf(init_like)+1;
                                        po.setLikenum(like_num.toString());
                                        po.update(new UpdateListener() {
                                            @Override
                                            public void done(BmobException e) {
                                                if(e==null){
                                                    Toast.makeText(Recive.this,"点赞成功",Toast.LENGTH_SHORT).show();
                                                    like.setImageResource(R.drawable.like1);
                                                }else{
                                                    Toast.makeText(Recive.this,"点赞失败",Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        });
                                    }
                                }else if(list.size()==0){
                                    //未被收藏
                                    Post po = new Post();
                                    po.setObjectId(id);
                                    BmobRelation relation2 = new BmobRelation();
                                    relation2.add(user);
                                    po.setRelation2(relation2);
                                    Integer like_num = Integer.valueOf(init_like)+1;
                                    po.setLikenum(like_num.toString());
                                    po.update(new UpdateListener() {
                                        @Override
                                        public void done(BmobException e) {
                                            if(e==null){
                                                Toast.makeText(Recive.this,"点赞成功",Toast.LENGTH_SHORT).show();
                                                like.setImageResource(R.drawable.like1);
                                            }else{
                                                Toast.makeText(Recive.this,"点赞失败",Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                                }
                            }
                        });
                    }
                });
            }
        });
        comment_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User user = BmobUser.getCurrentUser(User.class);
                Post post = new Post();
                post.setObjectId(id);
                final Comment comment = new Comment();
                comment.setContent(comment_edt.getText().toString());
                comment.setPost(post);
                comment.setUser(user);
                comment.save(new SaveListener<String>() {
                    @Override
                    public void done(String s, BmobException e) {
                        if(e==null){
                            Toast.makeText(Recive.this,"评论成功",Toast.LENGTH_SHORT).show();
                            comment_edt.setText("");
                            Refresh();
                        }else{
                            Toast.makeText(Recive.this,"评论失败",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }


    private void initView(){
        nickname = findViewById(R.id.recive_username);
        content = findViewById(R.id.recive_content);
        title = findViewById(R.id.recive_title);
        time = findViewById(R.id.recive_time);
        school = findViewById(R.id.recive_school);
        tupian = findViewById(R.id.recive_tupian);
        back = findViewById(R.id.back_to_community);
        photo = findViewById(R.id.recive_photo);
        comment_edt = findViewById(R.id.comment_edit);
        comment_btn = findViewById(R.id.btn_comment);
        comment_num = findViewById(R.id.comment_num);
        delete = findViewById(R.id.revice_delete);
        edit = findViewById(R.id.revice_edit);
        like = findViewById(R.id.recive_like);
        collect = findViewById(R.id.recive_collect);
        recyclerView = findViewById(R.id.comment_recycleview);
        swipeRefreshLayout = findViewById(R.id.comment_swipe);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
