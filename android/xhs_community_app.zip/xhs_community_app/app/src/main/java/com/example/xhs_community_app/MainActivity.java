package com.example.xhs_community_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.ashokvarma.bottomnavigation.BottomNavigationBar;
import com.ashokvarma.bottomnavigation.BottomNavigationItem;
import com.example.xhs_community_app.Adapter.SectionPageAdapter;
import com.example.xhs_community_app.Fragment.FragmentCommunity;
import com.example.xhs_community_app.Fragment.FragmentFabu;
import com.example.xhs_community_app.Fragment.FragmentMe;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements BottomNavigationBar.OnTabSelectedListener, ViewPager.OnPageChangeListener {

    private ViewPager viewPager;
    private BottomNavigationBar bottomNavigationBar;

    private List<Fragment> fragments;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewPager = findViewById(R.id.viewpage);
        bottomNavigationBar = findViewById(R.id.bottom);

        initView();
    }

    private void initView(){
        initViewPager();
        initBottomNavigationBar();
    }
//使用github上的底部导航栏
    private void initBottomNavigationBar() {
        bottomNavigationBar.setTabSelectedListener(this);
        bottomNavigationBar.clearAll();
        bottomNavigationBar.setMode(BottomNavigationBar.MODE_FIXED);    //自适应大小
        bottomNavigationBar.setBackgroundStyle(BottomNavigationBar.BACKGROUND_STYLE_DEFAULT);
        bottomNavigationBar.setBarBackgroundColor(R.color.white);
        bottomNavigationBar.addItem(new BottomNavigationItem(R.drawable.community2,"首页").setInactiveIconResource(R.drawable.community))
                .addItem(new BottomNavigationItem(R.drawable.fabu2,"发布").setInactiveIconResource(R.drawable.fabu))
                .addItem(new BottomNavigationItem(R.drawable.me2,"我").setInactiveIconResource(R.drawable.me))
                .setFirstSelectedPosition(0)
                .initialise();
    }

    private void initViewPager() {
        viewPager.setOffscreenPageLimit(3);

        fragments = new ArrayList<Fragment>();
        fragments.add(new FragmentCommunity());
        fragments.add(new FragmentFabu());
        fragments.add(new FragmentMe());

        viewPager.setAdapter(new SectionPageAdapter(getSupportFragmentManager(),fragments));
        viewPager.addOnPageChangeListener(this);
        viewPager.setCurrentItem(0);
    }

    @Override
    public void onTabSelected(int position) {
        viewPager.setCurrentItem(position);
    }

    @Override
    public void onTabUnselected(int position) {

    }

    @Override
    public void onTabReselected(int position) {

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        bottomNavigationBar.selectTab(position);
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}