package com.example.bmobloginservice;

import android.app.Application;

import cn.bmob.v3.Bmob;

public class BmobLoginServiceApplication extends Application {
    public static final String TAG = "bmob";
    // 短信模版名称
    public static final String SMS_TEMPLATE_NAME = "Register";
    @Override
    public void onCreate() {
        super.onCreate();
        // 初始化 Bmob SDK
        Bmob.initialize(this,"24902347d62425f082abf0104df8fb79");
    }
}
