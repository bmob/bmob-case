package com.gmsy.fragment.game;

import android.content.Intent;
import androidx.fragment.app.FragmentActivity;
import android.os.Bundle;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import com.czj.base.base.BaseFragment;
import com.gmsy.activity.WebActivity;
import com.gmsy.bean.GameBean;
import com.gmsy.bean.WebBean;
import com.gmsy.constant.Constant;
import com.gmsy.databinding.FragmentChildGameBinding;
import com.hjq.toast.ToastUtils;

public class ChildFragment extends BaseFragment<FragmentChildGameBinding> {
	private String title, http;
	private ChildViewModel viewmodel;
    private GameAdapter adapter;

	@Override
	protected void onInitView(Bundle arg0, FragmentChildGameBinding arg1, FragmentActivity arg2) {
	}

	@Override
	protected void lazyLoad() {
		Bundle bundle = getArguments();
		title = bundle.getString("title");
		http = bundle.getString("http");

		viewmodel = new ViewModelProvider(this).get(ChildViewModel.class);
		viewmodel.gethttp(http);
		initLiveData();
	}

	private void initLiveData() {
		viewmodel.list().observe(this, (list) -> {
			GridLayoutManager grid = new GridLayoutManager(context, 2);
			binding.rv.setLayoutManager(grid);
			adapter = new GameAdapter(list);
			binding.rv.setAdapter(adapter);

			binding.rv.setOnItemClickListener((v, i) -> {
				GameBean bean = adapter.getItemData(i);
				WebBean webbean = new WebBean();
				webbean.setTitle(bean.getTitle());
				webbean.setHttp(bean.getHttp());
                webbean.setIsshow(true);
				Intent intent = new Intent();
				intent.setClass(context, WebActivity.class);
				intent.putExtra(Constant.ACTION_WEB_KEY, webbean);
				startActivity(intent);
			});
            
            binding.rv.setOnLoadMoreListener(()->{
                viewmodel.addhttp(http);
            },1000);
		});
        
        
        viewmodel.addlist().observe(this,(list)->{
            adapter.addData(list);
            binding.rv.loadMoreComplete();
        });
	}
}
