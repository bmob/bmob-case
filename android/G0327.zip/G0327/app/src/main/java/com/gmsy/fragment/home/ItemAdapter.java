package com.gmsy.fragment.home;

import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.gmsy.R;
import com.gmsy.bmob.ItemBean;

import java.util.List;

import me.jingbin.library.adapter.BaseByViewHolder;
import me.jingbin.library.adapter.BaseRecyclerAdapter;

public class ItemAdapter extends BaseRecyclerAdapter<ItemBean> {

    public ItemAdapter(List<ItemBean> list) {
        super(R.layout.item, list);
    }

    @Override
    protected void bindView(BaseByViewHolder<ItemBean> arg0, ItemBean arg1, int arg2) {
        ImageView imageView = arg0.getView(R.id.iv);
        Glide.with(arg0.getByRecyclerView().getContext()).load(arg1.getImg()).transform(new RoundedCorners(15)).into(imageView);
        arg0.setText(R.id.tv, arg1.getTitle());
        arg0.setText(R.id.vice, arg1.getVice());
    }
}