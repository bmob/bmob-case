package com.gmsy.bmob;

import cn.bmob.v3.BmobObject;

public class ItemBean extends BmobObject {
    private String img;
    private String title;
    private String vice;
    private String js;
    private String url;

    public void setVice(String url) {
        this.vice = url;
    }

    public String getVice() {
        return vice;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setJs(String js) {
        this.js = js;
    }

    public String getJs() {
        return js;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getImg() {
        return img;
    }
}