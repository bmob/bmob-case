package com.gmsy.fragment.video;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;

import com.czj.base.base.BaseFragment;
import com.gmsy.activity.PlayerActivity;
import com.gmsy.bmob.Movies;
import com.gmsy.databinding.FragmentVideoBinding;
import com.gyf.immersionbar.ImmersionBar;

public class VidoeFragment extends BaseFragment<FragmentVideoBinding> {

    VideoAdapter adapter;
    private VideoViewModel viewmodel;

    @Override
    protected void onInitView(Bundle arg0, FragmentVideoBinding arg1, FragmentActivity arg2) {
        ImmersionBar.setTitleBar(this, binding.titlebar);
    }

    @Override
    protected void lazyLoad() {
        viewmodel = new ViewModelProvider(this).get(VideoViewModel.class);
        viewmodel.getMoviesList();
        initLiveData();
    }

    // LiveData观察者模式接收端
    private void initLiveData() {
        viewmodel.GetLiveData_Movies().observe(
                this,
                list -> {
                    // 接收影视列表数据
                    if (adapter == null) {
                        binding.rv.setLayoutManager(new GridLayoutManager(context, 2));
                        adapter = new VideoAdapter(list);
                        binding.rv.setAdapter(adapter);
                    } else {
                        adapter.setNewData(list);
                        binding.rv.setRefreshing(false);
                    }
                });

        // 列表点击事件
        binding.rv.setOnItemClickListener(
                (v, i) -> {
                    Movies bean = adapter.getItemData(i);
                    Intent intent = new Intent(context, PlayerActivity.class);
                    intent.putExtra("id", bean.getObjectId());
                    intent.putExtra("title", bean.getTitle());
                    intent.putExtra("player", bean.getPlays());
                    startActivity(intent);
                });
        //列表刷新事件
        binding.rv.setOnRefreshListener(
                () -> {
                    viewmodel.getMoviesList();
                });
    }
}
