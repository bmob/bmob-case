package com.gmsy.bmob;

import cn.bmob.v3.BmobObject;

public class UpdateBean extends BmobObject {
    // 更新内容
    private String content;
    // 版本号
    private String version;
    // 下载地址
    private String download;
    // 是否强制更新
    private boolean isshow;

    public String getDownload() {
        return download;
    }

    public void setDownload(String download) {
        this.download = download;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean getIsshow() {
        return this.isshow;
    }

    public void setIsshow(boolean isshow) {
        this.isshow = isshow;
    }
}
