package com.gmsy.bmob;

public class GameVideo extends TopBannerGameBean{
  
}
