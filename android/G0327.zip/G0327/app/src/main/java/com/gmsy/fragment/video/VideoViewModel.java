package com.gmsy.fragment.video;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.gmsy.bmob.GameVideo;
import com.gmsy.bmob.Movies;

import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

public class VideoViewModel extends ViewModel {

  private MutableLiveData<List<Movies>> liveData;
  public MutableLiveData<List<GameVideo>> rtTopBannerGameList = new MutableLiveData<>();

  // 获取Bmob影视列表
  public void getMoviesList() {
    BmobQuery<Movies> bmob = new BmobQuery<>();
    bmob.order("-createdAt");
    bmob.findObjects(
        new FindListener<Movies>() {

          @Override
          public void done(List<Movies> arg0, BmobException arg1) {
            if (arg1 == null) {
              GetLiveData_Movies().setValue(arg0);
            }
          }
        });
  }

  // 观察者模式发送端
  public MutableLiveData<List<Movies>> GetLiveData_Movies() {
    if (liveData == null) {
      liveData = new MutableLiveData<>();
    }
    return liveData;
  }

  public void getTopBannerGame() {
    BmobQuery<GameVideo> bmob = new BmobQuery<>();
    bmob.order("-createdAt");
    bmob.findObjects(
        new FindListener<GameVideo>() {

          @Override
          public void done(List<GameVideo> list, BmobException arg1) {
            if (arg1 == null) {
              rtTopBannerGameList.setValue(list);
            }
          }
        });
  }
}
