package com.gmsy.fragment.video;

import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.gmsy.R;
import com.gmsy.bmob.Movies;

import java.util.List;

import me.jingbin.library.adapter.BaseByViewHolder;
import me.jingbin.library.adapter.BaseRecyclerAdapter;

public class VideoAdapter extends BaseRecyclerAdapter<Movies> {

    public VideoAdapter(List<Movies> list) {
        super(R.layout.item_movies, list);
    }

    @Override
    protected void bindView(BaseByViewHolder<Movies> holder, Movies bean, int arg2) {
        holder.setText(R.id.tv_title, bean.getTitle());
        ImageView iv = holder.getView(R.id.iv_image);
        Glide.with(iv).load(bean.getImage()).into(iv);
    }
}
