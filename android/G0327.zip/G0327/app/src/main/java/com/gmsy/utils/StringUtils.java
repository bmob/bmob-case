package com.gmsy.utils;
import java.util.ArrayList;
import java.util.List;

public class StringUtils {
  public static String qc(Object obj, Object obj2, Object obj3) {
    String a = toString(obj);
    if (a == null) {
      return null;
    }
    int indexOf;
    if (obj2 != null) {
      int indexOf2;
      int length = a.length();
      if (obj2 instanceof String) {
        String str = (String) obj2;
        indexOf = a.indexOf(str);
        if (indexOf == -1) {
          return null;
        }
        indexOf += str.length();
      } else if (!(obj2 instanceof Number)) {
        return null;
      } else {
        indexOf = ((Number) obj2).intValue();
        if (indexOf < 0 || indexOf > length) {
          return null;
        }
      }
      if (obj3 instanceof String) {
        indexOf2 = a.indexOf((String) obj3, indexOf);
        if (indexOf2 == -1) {
          return null;
        }
      } else if (!(obj3 instanceof Number)) {
        return a.substring(indexOf);
      } else {
        indexOf2 = ((Number) obj3).intValue();
        if (indexOf2 < 0 || indexOf2 > length) {
          return null;
        }
      }
      return indexOf > indexOf2 ? null : a.substring(indexOf, indexOf2);
    } else if (obj3 instanceof String) {
      indexOf = a.indexOf((String) obj3);
      return indexOf == -1 ? null : a.substring(0, indexOf);
    } else if (!(obj3 instanceof Number)) {
      return null;
    } else {
      indexOf = ((Number) obj3).intValue();
      return (indexOf < 0 || indexOf > a.length()) ? null : a.substring(0, indexOf);
    }
  }

  public static String toString(Object obj) {
    try {
      return (String) obj;
    } catch (ClassCastException e) {
      return null;
    }
  }

  public static String[] fg(String str, String str2) {
    int i = 0;
    if (str == null) {
      return null;
    }
    int length = str.length();
    if (length == 0) {
      return new String[0];
    }
    int length2;
    int i2;
    int i3;
    if (str2 != null && !"".equals(str2)) {
      length2 = str2.length();
      ArrayList arrayList = new ArrayList();
      i2 = 0;
      i3 = 0;
      while (i < length) {
        i = str.indexOf(str2, i2);
        if (i < 0) {
          arrayList.add(str.substring(i2));
          i = length;
        } else if (i > i2) {
          i3++;
          if (i3 == -1) {
            arrayList.add(str.substring(i2));
            i = length;
          } else {
            arrayList.add(str.substring(i2, i));
            i2 = i + length2;
          }
        } else {
          i2 = i + length2;
        }
      }
      return (String[]) arrayList.toArray(new String[arrayList.size()]);
    } else if (str == null) {
      return null;
    } else {
      length = str.length();
      if (length == 0) {
        return new String[0];
      }
      List arrayList2 = new ArrayList();
      i3 = 0;
      int i4 = 0;
      i2 = 0;
      length2 = 1;
      while (i2 < length) {
        if (Character.isWhitespace(str.charAt(i2))) {
          int i5;
          if (i3 != 0) {
            i3 = length2 + 1;
            if (length2 == -1) {
              i2 = length;
            }
            arrayList2.add(str.substring(i4, i2));
            length2 = i3;
            i3 = i2;
            i2 = 0;
          } else {
            i5 = i3;
            i3 = i2;
            i2 = i5;
          }
          i3++;
          i4 = i3;
          i5 = i2;
          i2 = i3;
          i3 = i5;
        } else {
          i2++;
          i3 = 1;
        }
      }
      if (i3 != 0) {
        arrayList2.add(str.substring(i4, i2));
      }
      return (String[]) arrayList2.toArray(new String[arrayList2.size()]);
    }
  }
}
