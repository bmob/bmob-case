package com.gmsy.base;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaseViewModel extends ViewModel{
    /*
        分两个map是为了MutableLiveData<T>和MutableLiveData<List<T>>不会互相覆盖，因为Key值都是T类型的.class
     */
 
    /**
     * 此map直接存储实例MutableLiveData(泛型T)
     */
    private Map<Class<?>, MutableLiveData<?>> map = new HashMap<>();
 
    /**
     * 此map直接存储实例MutableLiveData(List包含泛型T）
     */
    private Map<Class<?>, MutableLiveData<?>> map2 = new HashMap<>();
 
    /**
     * 创建一个类型是T的MutableLiveData实例
     * @param t T类的.class
     * @param <T> T类型
     * @return MutableLiveData实例
     */
    @SuppressWarnings("unchecked")
    public <T> MutableLiveData<T> getMutableLiveData(Class<T> t) {
        MutableLiveData<?> liveData = map.get(t);
 
        if (liveData == null) {
            liveData = new MutableLiveData<T>();
            map.put(t, liveData);
        }
        return (MutableLiveData<T>) liveData;
    }
 
    /**
     * 创建一个类型是List的MutableLiveData实例
     * @param t T类的.class
     * @param <T> T类型
     * @return MutableLiveData实例
     */
    @SuppressWarnings("unchecked")
    public <T> MutableLiveData<List<T>> getMutableLiveDataList(Class<T> t) {
        MutableLiveData<?> liveData = map2.get(t);
 
        if (liveData == null) {
            liveData = new MutableLiveData<List<T>>();
            map2.put(t, liveData);
        }
        return (MutableLiveData<List<T>>) liveData;
    }
}
