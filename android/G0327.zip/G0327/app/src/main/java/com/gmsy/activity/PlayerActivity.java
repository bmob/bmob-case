package com.gmsy.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.czj.base.base.BaseActivity;
import com.gmsy.bmob.Movies;
import com.gmsy.databinding.ActivityPlayerBinding;
import com.gyf.immersionbar.ImmersionBar;
import com.hjq.bar.OnTitleBarListener;
import com.hjq.bar.TitleBar;

import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.UpdateListener;
import xyz.doikki.videocontroller.StandardVideoController;

public class PlayerActivity extends BaseActivity<ActivityPlayerBinding>
        implements OnTitleBarListener {

    private String BmobID;

    @Override
    protected void initActivity(Bundle arg0) {
        ImmersionBar.setTitleBar(this, binding.titlebar);
        initPlay();
        initBrowse();
        binding.titlebar.setOnTitleBarListener(this);
    }

    private void initBrowse() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Movies movies = new Movies();
                movies.setObjectId(BmobID);
                movies.increment("browse");
                movies.update(new UpdateListener() {
                    @Override
                    public void done(BmobException e) {
                        if (e == null) {
                            Log.d("Bmob", "增加播放次数成功");
                        }
                    }
                });
            }
        }, 2000);
    }

    private void initPlay() {
        Intent intent = getIntent();
        BmobID = intent.getStringExtra("id");
        String plays = intent.getStringExtra("player");
        String title = intent.getStringExtra("title");
        binding.player.setUrl(plays); // 设置视频地址
        StandardVideoController controller = new StandardVideoController(this);
        controller.addDefaultControlComponent(title, false);
        binding.player.setVideoController(controller); // 设置控制器
        binding.player.start(); // 开始播放，不调用则不自动播放
    }

    @Override
    public void onLeftClick(TitleBar arg0) {
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        binding.player.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        binding.player.resume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding.player.release();
    }

    @Override
    public void onBackPressed() {
        if (!binding.player.onBackPressed()) {
            super.onBackPressed();
        }
    }
}
