package com.gmsy.fragment.game;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import android.os.Bundle;
import com.czj.base.adapter.PagerAdapter2;
import com.czj.base.base.BaseFragment;
import com.gmsy.bean.GameBean;
import com.gmsy.constant.Constant;
import com.gmsy.databinding.FragmentGameBinding;
import com.google.android.material.tabs.TabLayoutMediator;
import com.gyf.immersionbar.ImmersionBar;
import java.util.ArrayList;
import java.util.List;

public class GameFragment extends BaseFragment<FragmentGameBinding> {
    
  private List<GameBean> list;
  private List<Fragment> fragments;

  @Override
  protected void onInitView(Bundle arg0, FragmentGameBinding arg1, FragmentActivity arg2) {
    ImmersionBar.setTitleBar(this, binding.titlebar);
  }

  @Override
  protected void lazyLoad() {
    initVP();
  }
  
  
  
  private void initVP(){
      fragments = new ArrayList<>();
      for(int i = 0 ; i < getlist().size(); i++){
          GameBean bean = getlist().get(i);
          ChildFragment fragment = new ChildFragment();
          Bundle bundle = new Bundle();
          bundle.putString("http",bean.getHttp());
          bundle.putString("title",bean.getTitle());
          fragment.setArguments(bundle);
          fragments.add(fragment);
      }
      PagerAdapter2 adapter = new PagerAdapter2(getChildFragmentManager(),getLifecycle(),fragments);
      binding.viewpager.setAdapter(adapter);
      binding.viewpager.setOffscreenPageLimit(3);
      new TabLayoutMediator(binding.mTablayout,binding.viewpager,true,(tab,i)->{
          tab.setText(list.get(i).getTitle());
      }).attach();
      
  }

  private List<GameBean> getlist() {
    list = new ArrayList<>();
    list.clear();
    GameBean game1 = new GameBean();
    game1.setHttp("&tag=0");
    game1.setTitle("FC游戏");

    GameBean game2 = new GameBean();
    game2.setHttp("&tag=9");
    game2.setTitle("街机游戏");

    GameBean game3 = new GameBean();
    game3.setHttp("&tag=11");
    game3.setTitle("GBA游戏");

    GameBean game4 = new GameBean();
    game4.setHttp("&tag=13");
    game4.setTitle("MD游戏");

    GameBean game5 = new GameBean();
    game5.setHttp("&tag=1");
    game5.setTitle("H5游戏");
        
        
    list.add(game1);
    list.add(game2);
    list.add(game3);
    list.add(game4);
    list.add(game5);

    return list;
  }
}
