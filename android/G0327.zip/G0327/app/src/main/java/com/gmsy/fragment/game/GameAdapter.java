package com.gmsy.fragment.game;

import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.gmsy.bean.GameBean;
import com.gmsy.fragment.game.GameAdapter;
import java.util.List;
import me.jingbin.library.adapter.BaseByViewHolder;
import me.jingbin.library.adapter.BaseRecyclerAdapter;
import com.gmsy.R;

public class GameAdapter extends BaseRecyclerAdapter<GameBean> {
    
    public GameAdapter(List<GameBean> list){
        super(R.layout.item_game,list);
    }

  @Override
  protected void bindView(BaseByViewHolder<GameBean> arg0, GameBean arg1, int arg2) {
      ImageView imag = arg0.getView(R.id.iv_imag);
      Glide.with(imag).load(arg1.getImag()).into(imag);
      arg0.setText(R.id.tv_name,arg1.getTitle());
  }
}
