package com.gmsy.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.czj.base.base.BaseActivity;
import com.gmsy.databinding.ActivitySettingBinding;
import com.gmsy.utils.GlideCacheUtil;
import com.gyf.immersionbar.ImmersionBar;
import com.hjq.bar.OnTitleBarListener;
import com.hjq.bar.TitleBar;

public class SettingActivity extends BaseActivity<ActivitySettingBinding> {
    @Override
    protected void initActivity(Bundle bundle) {
        ImmersionBar.setTitleBar(this, binding.title);
        initTItle();
    }

    private void initTItle() {
        String GLideSize = GlideCacheUtil.getInstance().getCacheSize(context);
        binding.SBSize.setRightText(GLideSize);
        binding.SBSize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GlideCacheUtil.getInstance().clearImageAllCache(context);
                binding.SBSize.setRightText("0.00B");
            }
        });
        binding.SBAbout.setOnClickListener((v) -> {
            Intent intent = new Intent(context, AboutActivity.class);
            startActivity(intent);
        });

        binding.title.setOnTitleBarListener(new OnTitleBarListener() {
            @Override
            public void onLeftClick(TitleBar titleBar) {
                finish();
            }
        });
    }
}
