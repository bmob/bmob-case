package com.gmsy.fragment.game;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.gmsy.base.BaseViewModel;
import com.gmsy.bean.GameBean;
import com.gmsy.constant.Constant;
import com.gmsy.utils.StringUtils;
import com.hjq.toast.ToastUtils;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;
import java.util.ArrayList;
import java.util.List;

public class ChildViewModel extends BaseViewModel {
    private int pager = 1;
    private MutableLiveData<List<GameBean>> addlist;

	public void gethttp(String http) {
        
		OkGo.<String>get(Constant.Game_Id + "/nes?page=" + pager + http+"&e=").execute(new StringCallback() {
			@Override
			public void onSuccess(Response<String> arg0) {
				String bean = arg0.body();
				String log = bean.replace("\"", "");
				String http = StringUtils.qc(log,
						"<h2 style=text-align: left; margin-top::30px;margin-bottom:30px>所有游戏</h2>",
						"<div id=back-top><a href=javascript:void(0)><i class=fa fa-arrow-circle-up fa-3x></i></a></div>");
				http = StringUtils.qc(http, "<div class=col-md-3 col-xs-6>", null);
				String[] fg = StringUtils.fg(http, "<div class=col-md-3 col-xs-6>");
                List<GameBean> listbean = new ArrayList<>();
				for (String me : fg) {
					String url = StringUtils.qc(me, "<a  href=", ">");
					String url1 = Constant.Game_Id + url;
					String img = StringUtils.qc(me, "<img class=img img-raised src=", ">");
					String name = StringUtils.qc(me, "<h4 class=card-caption>", null);
					name = StringUtils.qc(name, ">", "</a>");
                    GameBean game = new GameBean();
                    game.setHttp(url1);
                    game.setTitle(name);
                    game.setImag(img);
                    listbean.add(game);
				}
                list().postValue(listbean);
			}
		});
	}
    
    public void addhttp(String http) {
        pager ++;
		OkGo.<String>get(Constant.Game_Id + "/nes?page=" + pager + http +"&e=").execute(new StringCallback() {
			@Override
			public void onSuccess(Response<String> arg0) {
				String bean = arg0.body();
				String log = bean.replace("\"", "");
				String http = StringUtils.qc(log,
						"<h2 style=text-align: left; margin-top::30px;margin-bottom:30px>所有游戏</h2>",
						"<div id=back-top><a href=javascript:void(0)><i class=fa fa-arrow-circle-up fa-3x></i></a></div>");
				http = StringUtils.qc(http, "<div class=col-md-3 col-xs-6>", null);
				String[] fg = StringUtils.fg(http, "<div class=col-md-3 col-xs-6>");
                List<GameBean> listbean = new ArrayList<>();
				for (String me : fg) {
					String url = StringUtils.qc(me, "<a  href=", ">");
					String url1 = Constant.Game_Id + url;
					String img = StringUtils.qc(me, "<img class=img img-raised src=", ">");
					String name = StringUtils.qc(me, "<h4 class=card-caption>", null);
					name = StringUtils.qc(name, ">", "</a>");
                    GameBean game = new GameBean();
                    game.setHttp(url1);
                    game.setTitle(name);
                    game.setImag(img);
                    listbean.add(game);
				}
                addlist().postValue(listbean);
			}
		});
	}


	public MutableLiveData<String> showLog() {
		return getMutableLiveData(String.class);
	}

	public MutableLiveData<List<GameBean>> list() {
		return getMutableLiveDataList(GameBean.class);
	}
    
    public MutableLiveData<List<GameBean>> addlist() {
        if(addlist == null){
            addlist = new MutableLiveData<List<GameBean>>();
        }
		return addlist;
	}
}
