package com.gmsy.fragment.home;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import cn.bmob.v3.listener.SaveListener;
import com.gmsy.bmob.Banner;
import com.gmsy.bmob.ItemBean;
import com.gmsy.bmob.NoticeBean;
import com.gmsy.bmob.TopBannerGameBean;
import com.gmsy.constant.Constant;
import com.gmsy.entity.CustomViewsInfo;
import com.hjq.toast.ToastUtils;

import java.util.ArrayList;
import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.QueryListener;

public class HomeViewModel extends ViewModel {

  private MutableLiveData<NoticeBean> noticebean;
  private MutableLiveData<List<CustomViewsInfo>> getBannerLiveData;
  private MutableLiveData<List<ItemBean>> itembeanlivedata;

  public MutableLiveData<List<TopBannerGameBean>> rtTopBannerGameList = new MutableLiveData<>();

  public void getBannerList() {

    BmobQuery<Banner> query = new BmobQuery<>();

    query.findObjects(
        new FindListener<Banner>() {

          @Override
          public void done(List<Banner> bean, BmobException e) {
            if (e == null) {
              List<CustomViewsInfo> list = new ArrayList<>();
              for (int i = 0; i < bean.size(); i++) {
                CustomViewsInfo bannerBean = new CustomViewsInfo();
                bannerBean.setImg(bean.get(i).getImg());
                bannerBean.setTitle(bean.get(i).getTitle());
                bannerBean.setUrl(bean.get(i).getUrl());
                list.add(bannerBean);
              }
              GetBannerLiveData().setValue(list);
            } else {
              ToastUtils.show("查询失败");
            }
          }
        });
  }

  public void initItemBeanlist() {
    BmobQuery<ItemBean> bmob = new BmobQuery<>();
    bmob.findObjects(
        new FindListener<ItemBean>() {

          @Override
          public void done(List<ItemBean> arg0, BmobException arg1) {
            if (arg1 == null) {
              getItembeanlivedata().setValue(arg0);
            }
          }
        });
  }

  public void getNoticeBean() {
    BmobQuery<NoticeBean> bmob = new BmobQuery<>();
    bmob.getObject(
        Constant.Bmob_NoticID,
        new QueryListener<NoticeBean>() {
          @Override
          public void done(NoticeBean arg0, BmobException arg1) {
            getNotice().setValue(arg0);
          }
        });
  }

  public MutableLiveData<NoticeBean> getNotice() {
    if (noticebean == null) {
      noticebean = new MutableLiveData<>();
    }
    return noticebean;
  }

  public MutableLiveData<List<CustomViewsInfo>> GetBannerLiveData() {
    if (getBannerLiveData == null) {
      getBannerLiveData = new MutableLiveData<List<CustomViewsInfo>>();
    }
    return this.getBannerLiveData;
  }

  public MutableLiveData<List<ItemBean>> getItembeanlivedata() {
    if (itembeanlivedata == null) {
      itembeanlivedata = new MutableLiveData<List<ItemBean>>();
    }
    return this.itembeanlivedata;
  }

  public void getTopBannerGame() {
    List<TopBannerGameBean> list = new ArrayList<>();
    BmobQuery<TopBannerGameBean> bmob = new BmobQuery<>();
    bmob.findObjects(
        new FindListener<TopBannerGameBean>() {

          @Override
          public void done(List<TopBannerGameBean> list, BmobException arg1) {
            if (arg1 == null) {
              rtTopBannerGameList.setValue(list);
            }
          }
        });
  }
}
