package com.gmsy.bmob;

import cn.bmob.v3.BmobObject;

public class Banner extends BmobObject {
    private String url;
    private String img;
    private String title;

    public String getUrl() {
        return this.url;
    }

    public void setUrl(String a) {
        this.url = a;
    }

    public String getImg() {
        return this.img;
    }

    public void setImg(String b) {
        this.img = b;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String c) {
        this.title = c;
    }
}
