package com.gmsy.fragment.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.czj.base.base.BaseFragment;
import com.czj.base.utils.EquipmentUtils;
import com.gmsy.R;
import com.gmsy.activity.WebActivity;
import com.gmsy.bean.WebBean;
import com.gmsy.bmob.ItemBean;
import com.gmsy.bmob.TopBannerGameBean;
import com.gmsy.bmob.UpdateBean;
import com.gmsy.constant.Constant;
import com.gmsy.databinding.FragmentHomeBinding;
import com.gmsy.dialog.UpdateDialog;
import com.gyf.immersionbar.ImmersionBar;
import com.hjq.toast.ToastUtils;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.enums.PopupAnimation;
import com.stx.xhb.androidx.transformers.Transformer;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.QueryListener;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import android.os.Bundle;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jzvd.Jzvd;
import com.czj.base.base.BaseFragment;
import com.gmsy.R;
import com.gmsy.bmob.GameVideo;
import com.gmsy.databinding.FragmentVideoBinding;
import com.gmsy.fragment.home.HomeViewModel;
import com.gmsy.fragment.home.TopBannerGameAdapter;
import com.gmsy.utils.AutoPlayUtils;
import com.gyf.immersionbar.ImmersionBar;

public class HomeFragment extends BaseFragment<FragmentHomeBinding> {

  private HomeViewModel viewmodel;
  private TopBannerGameAdapter topAdapter;
  private LinearLayoutManager mLayoutManager;

  @Override
  protected void onInitView(Bundle arg0, FragmentHomeBinding arg1, FragmentActivity arg2) {
    ImmersionBar.setTitleBar(this, binding.view);
  }

  @Override
  protected void lazyLoad() {
    viewmodel = new ViewModelProvider(this).get(HomeViewModel.class);
    viewmodel.getBannerList();
    viewmodel.initItemBeanlist();
    viewmodel.getNoticeBean();
    viewmodel.getTopBannerGame();
    initLiveEventBus();
    initOnclick();
    init_update_dialog();
  }

  private void init_update_dialog() {
    BmobQuery<UpdateBean> bmobQuery = new BmobQuery<>();
    bmobQuery.getObject(
        Constant.Bmob_UpdateID,
        new QueryListener<UpdateBean>() {
          @Override
          public void done(UpdateBean bean, BmobException e) {
            Double version = Double.parseDouble(bean.getVersion());
            Double me_version = Double.parseDouble(EquipmentUtils.getAppVersionName(context));
            if (me_version < version) {
              new XPopup.Builder(context)
                  .dismissOnBackPressed(false)
                  .dismissOnTouchOutside(false)
                  .popupAnimation(PopupAnimation.TranslateFromBottom)
                  .asCustom(new UpdateDialog(context, bean))
                  .show();
            }
          }
        });
  }

  private void initOnclick() {
    binding.llOne.setOnClickListener(
        v -> {
          跳转客服();
        });

    binding.llTow.setOnClickListener(
        v -> {
          购买包站();
        });

    binding.llThree.setOnClickListener(
        v -> {
          GM游戏();
        });

    binding.llFour.setOnClickListener(
        v -> {
          BT游戏();
        });
  }

  private void GM游戏() {
    WebBean bean = new WebBean();
    bean.setHttp("http://qs123.998.co");
    bean.setTitle("10元正版GM");
    Intent intent = new Intent();
    intent.setClass(context, WebActivity.class);
    intent.putExtra(Constant.ACTION_WEB_KEY, bean);
    startActivity(intent);
  }

  private void 跳转客服() {
    Intent intent = new Intent();
    intent.setData(
        Uri.parse(
            "mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=272926947"));
    try {
      startActivity(intent);
    } catch (Exception e) {
      ToastUtils.show("您还没有安装QQ，请先安装软件");
    }
  }

  private void BT游戏() {
    WebBean bean = new WebBean();
    bean.setHttp("http://youxi.bbbtgo.com/h5/?chl=354617");
    bean.setTitle("返利BT手游");
    Intent intent = new Intent();
    intent.putExtra(Constant.ACTION_WEB_KEY, bean);
    intent.setClass(context, WebActivity.class);

    startActivity(intent);
  }

  private void 购买包站() {
    //WebBean bean = new WebBean();
    //bean.setHttp(Constant.Taobao);
    //bean.setTitle("购买包站");
    //Intent intent = new Intent();
    //intent.putExtra(Constant.ACTION_WEB_KEY, bean);
    //intent.setClass(context, WebActivity.class);
    //startActivity(intent);
     Intent intent = new Intent();
     intent.setAction("Android.intent.action.VIEW");
     intent.setData(Uri.parse(Constant.Taobao));
     intent.setClassName("com.taobao.taobao", "com.taobao.tao.detail.activity.DetailActivity");
     startActivity(intent);
  }

  // 监听LiveData消息，用于刷新ui
  private void initLiveEventBus() {
    viewmodel.GetBannerLiveData()
        .observe(
            this,
            (list) -> {
              binding.banner.setPageTransformer(Transformer.Scale);
              binding.banner.setBannerData(list);
              binding.banner.loadImage(
                  (banner, mobel, view, position) -> {
                    Glide.with(context)
                        .load(list.get(position).getImg())
                        .transform(new RoundedCorners(15))
                        .into((ImageView) view);
                  });

              binding.banner.setOnItemClickListener(
                  (banner, mobel, view, position) -> {
                    WebBean bean = new WebBean();
                    bean.setTitle(list.get(position).getTitle());
                    bean.setHttp(list.get(position).getUrl());
                    Intent intent = new Intent(context, WebActivity.class);
                    intent.putExtra(Constant.ACTION_WEB_KEY, bean);
                    startActivity(intent);
                  });
            });
    viewmodel
        .getItembeanlivedata()
        .observe(
            this,
            (list) -> {
              binding.rv.setLayoutManager(new GridLayoutManager(context, 2));
              ItemAdapter adapter = new ItemAdapter(list);
              binding.rv.setAdapter(adapter);

              binding.rv.setOnItemClickListener(
                  (v, i) -> {
                    ItemBean bean = adapter.getItemData(i);
                    WebBean webbean = new WebBean();
                    webbean.setHttp(bean.getUrl());
                    webbean.setTitle(bean.getTitle());
                    webbean.setJavascript(bean.getJs());
                    Intent intent = new Intent(context, WebActivity.class);
                    intent.putExtra(Constant.ACTION_WEB_KEY, webbean);
                    startActivity(intent);
                  });
            });
    viewmodel
        .getNotice()
        .observe(
            this,
            bean -> {
              if (bean.getIsShow()) {
                new XPopup.Builder(context)
                    .dismissOnBackPressed(false)
                    .dismissOnTouchOutside(false)
                    .asConfirm("温馨提示", bean.getConntent(), () -> {})
                    .show();
              }
            });

    viewmodel.rtTopBannerGameList.observe(
        this,
        list -> {
          mLayoutManager = new LinearLayoutManager(context, RecyclerView.HORIZONTAL, false);
          binding.toprv.setLayoutManager(mLayoutManager);
          topAdapter = new TopBannerGameAdapter(list);
          binding.toprv.setAdapter(topAdapter);
        });

    binding.toprv.addOnChildAttachStateChangeListener(
        new RecyclerView.OnChildAttachStateChangeListener() {
          @Override
          public void onChildViewAttachedToWindow(View view) {}

          @Override
          public void onChildViewDetachedFromWindow(View view) {
            Jzvd jzvd = view.findViewById(R.id.jz_video);
            if (jzvd != null
                && Jzvd.CURRENT_JZVD != null
                && jzvd.jzDataSource.containsTheUrl(
                    Jzvd.CURRENT_JZVD.jzDataSource.getCurrentUrl())) {
              if (Jzvd.CURRENT_JZVD != null && Jzvd.CURRENT_JZVD.screen != Jzvd.SCREEN_FULLSCREEN) {
                Jzvd.releaseAllVideos();
              }
            }
          }
        });

    binding.toprv.addOnScrollListener(
        new RecyclerView.OnScrollListener() {
          @Override
          public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            if (newState == RecyclerView.SCROLL_STATE_IDLE) {
              AutoPlayUtils.onScrollPlayVideo(
                  binding.toprv,
                  R.id.jz_video,
                  mLayoutManager.findFirstVisibleItemPosition(),
                  mLayoutManager.findLastVisibleItemPosition());
            }
          }

          @Override
          public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            if (dy != 0) {
              AutoPlayUtils.onScrollReleaseAllVideos(
                  mLayoutManager.findFirstVisibleItemPosition(),
                  mLayoutManager.findLastVisibleItemPosition(),
                  0.2f);
            }
          }
        });

    binding.toprv.setOnItemChildClickListener(
        (view, size) -> {
          TopBannerGameBean bean = topAdapter.getItemData(size);
          if (view.getId() == R.id.kp2) {
            WebBean webbean = new WebBean();
            webbean.setHttp(bean.getXiazai());
            webbean.setTitle(bean.getName());
            // webbean.setJavascript(bean.getJs());
            Intent intent = new Intent(context, WebActivity.class);
            intent.putExtra(Constant.ACTION_WEB_KEY, webbean);
            startActivity(intent);
          }
        });

    binding.toprv.setOnItemClickListener(
        (view, size) -> {
          TopBannerGameBean bean = topAdapter.getItemData(size);
          WebBean webbean = new WebBean();
          webbean.setHttp(bean.getXiazai());
          webbean.setTitle(bean.getName());
          // webbean.setJavascript(bean.getJs());
          Intent intent = new Intent(context, WebActivity.class);
          intent.putExtra(Constant.ACTION_WEB_KEY, webbean);
          startActivity(intent);
        });
  }
}
