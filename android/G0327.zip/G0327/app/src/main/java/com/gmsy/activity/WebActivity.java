package com.gmsy.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

import com.czj.base.base.BaseActivity;
import com.czj.base.utils.iAppLog;
import com.gmsy.bean.WebBean;
import com.gmsy.constant.Constant;
import com.gmsy.databinding.ActivityWebBinding;
import com.gmsy.utils.WebTools;
import com.gyf.immersionbar.BarHide;
import com.gyf.immersionbar.ImmersionBar;
import com.hjq.bar.OnTitleBarListener;
import com.hjq.bar.TitleBar;

import com.hjq.toast.ToastUtils;
import java.util.Timer;
import java.util.TimerTask;

import me.jingbin.web.ByWebView;
import me.jingbin.web.OnByWebClientCallback;

public class WebActivity extends BaseActivity<ActivityWebBinding> {
  private WebBean webbean;
  private ByWebView mByWebView;
  private Timer timer;
  private final OnByWebClientCallback onByWebClientCallback =
      new OnByWebClientCallback() {
        /* 网页加载过程中执行*/
        @Override
        public void onPageStarted(WebView webview, String http, Bitmap arg2) {
          if (!TextUtils.isEmpty(webbean.getJavascript())) {
            if (webbean.getHttp().contains(http)) {
              timer = new Timer();
              timer.schedule(
                  new TimerTask() {
                    @Override
                    public void run() {
                      runOnUiThread(
                          () -> {
                            mByWebView.getLoadJsHolder().loadJs(webbean.getJavascript());
                          });
                    }
                  },
                  0,
                  100);
            }
          }
          if (http.contains("xx.zgjdjt.com")) {
            webview
                .getSettings()
                .setUserAgentString(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36");
          } else {
            webview
                .getSettings()
                .setUserAgentString(
                    "Mozilla/5.0 (Linux; Android 11; M2012K11AC) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.58 Mobile Safari/537.36");
          }
        }

        /* 网页加载完成 */
        @Override
        public void onPageFinished(WebView arg0, String http) {
          if (timer != null) {
            timer.cancel();
            mByWebView.getLoadJsHolder().loadJs(webbean.getJavascript());
          }
          if (http.contains("123pan.com")
              || http.contains("pan.paosui.top")
              || http.contains("gongyipan.top")
              || http.contains("yunpan.com")
              || http.contains("down.xzt186.com")) {
            WebTools.openLink(WebActivity.this, http);
          }
        }
        
        //处理第三方链接
        @Override
        public boolean isOpenThirdApp(String arg0) {
            // TODO: Implement this method
            //Log.d("http",arg0);
            return WebTools.handleThirdApp(WebActivity.this,arg0);
        }
        
      };

  @Override
  protected void initActivity(Bundle arg0) {
    ImmersionBar.setTitleBar(this, binding.titlebar);
    initLiveEventBus();
    leftIconClick();
    initWebView();
  }

  /* 接收HomeFragment传递参数 */
  private void initLiveEventBus() {
    webbean = (WebBean) getIntent().getSerializableExtra(Constant.ACTION_WEB_KEY);
    binding.titlebar.setTitle(webbean.getTitle());
    if(webbean.getIsshow()){
        binding.titlebar.setVisibility(8);
    }
  }

  /* 左标题按钮事件 */
  private void leftIconClick() {
    binding.titlebar.setOnTitleBarListener(
        new OnTitleBarListener() {
          @Override
          public void onLeftClick(TitleBar arg0) {
            finish();
          }
        });
  }

  private void initWebView() {
    mByWebView =
        ByWebView.with(this)
            .setWebParent(binding.webview, new LinearLayout.LayoutParams(-1, -1))
            .useWebProgress("#248067")
            .setOnByWebClientCallback(onByWebClientCallback)
            .loadUrl(webbean.getHttp());
  }

  @Override
  protected void onPause() {
    super.onPause();
    mByWebView.onPause();
  }

  @Override
  protected void onResume() {
    super.onResume();
    mByWebView.onResume();
  }

  @Override
  protected void onDestroy() {
    mByWebView.onDestroy();
    super.onDestroy();
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
    super.onActivityResult(requestCode, resultCode, intent);
    mByWebView.handleFileChooser(requestCode, resultCode, intent);
  }

  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    if (mByWebView.handleKeyEvent(keyCode, event)) {
      return true;
    } else {
      return super.onKeyDown(keyCode, event);
    }
  }

  @Override
  public void onConfigurationChanged(Configuration newConfig) {
    super.onConfigurationChanged(newConfig);
    if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
      ImmersionBar.with(this).hideBar(BarHide.FLAG_HIDE_BAR).init();
    } else {
       getStatusBarConfig().reset();
       ImmersionBar.with(this).statusBarDarkFont(true).init();
    }
  }
}
