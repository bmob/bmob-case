package com.gmsy.entity;

import com.stx.xhb.androidx.entity.BaseBannerInfo;

public class CustomViewsInfo implements BaseBannerInfo {

    private String url;
    private String img;
    private String title;

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getImg() {
        return img;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    @Override
    public Object getXBannerUrl() {
        return this.img;
    }

    @Override
    public String getXBannerTitle() {
        return this.title;
    }
}
