package com.gmsy;

import android.app.Application;

import com.gmsy.constant.Constant;
import com.hjq.toast.ToastUtils;

import cn.bmob.v3.Bmob;
import com.lzy.okgo.OkGo;
import xyz.doikki.videoplayer.ijk.IjkPlayerFactory;
import xyz.doikki.videoplayer.player.VideoViewConfig;
import xyz.doikki.videoplayer.player.VideoViewManager;

public class App extends Application {
  @Override
  public void onCreate() {
    super.onCreate();
    OkGo.getInstance().init(this);
    ToastUtils.init(this);
    Bmob.resetDomain(Constant.Bmob_HTTP);
    Bmob.initialize(this, Constant.Bmob_APPId);
    VideoViewManager.setConfig(
        VideoViewConfig.newBuilder()
            // 使用使用IjkPlayer解码
            .setPlayerFactory(IjkPlayerFactory.create())
            .build());
  }
}
