package com.gmsy.fragment.more;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import androidx.recyclerview.widget.GridLayoutManager;

import com.gmsy.R;
import com.gmsy.activity.WebActivity;
import com.gmsy.bean.WebBean;
import com.gmsy.bmob.MoreBean;
import com.gmsy.bmob.MoreSon;
import com.gmsy.constant.Constant;

import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.QueryListener;
import me.jingbin.library.ByRecyclerView;
import me.jingbin.library.adapter.BaseByViewHolder;
import me.jingbin.library.adapter.BaseRecyclerAdapter;

public class MoreSonAdapter extends BaseRecyclerAdapter<MoreSon> {
    private final Context context;

    public MoreSonAdapter(Context context, List<MoreSon> list) {
        super(R.layout.item_moreson, list);
        this.context = context;
    }

    @Override
    protected void bindView(BaseByViewHolder<MoreSon> baseByViewHolder, MoreSon moreSon, int i) {
        baseByViewHolder.setText(R.id.tv_name, moreSon.getName());
        String bmom_id = moreSon.getObjectId();
        ByRecyclerView mRecyclerView = baseByViewHolder.getView(R.id.mRecyclerView);
        mRecyclerView.setLayoutManager(new GridLayoutManager(baseByViewHolder.getByRecyclerView().getContext(), 4));
        getMoreBeanList(bmom_id, new OnData() {
            @Override
            public void onlist(List<MoreBean> list) {
                MoreAdapter adapter = new MoreAdapter(list);
                mRecyclerView.setAdapter(adapter);
                mRecyclerView.setOnItemClickListener(new ByRecyclerView.OnItemClickListener() {
                    @Override
                    public void onClick(View view, int i) {
                        MoreBean bean = adapter.getItemData(i);
                        WebBean webbean = new WebBean();
                        webbean.setTitle(bean.getTitle());
                        webbean.setHttp(bean.getUrl());
                        webbean.setJavascript(bean.getJs());
                        Intent intent = new Intent();
                        intent.setClass(context, WebActivity.class);
                        intent.putExtra(Constant.ACTION_WEB_KEY, webbean);
                        context.startActivity(intent);
                    }
                });
            }
        });
    }

    private void getMoreBeanList(String bmom_id, OnData onData) {
        BmobQuery<MoreBean> bmob = new BmobQuery<>();
        bmob.addWhereEqualTo("moreson",bmom_id);
        bmob.include("moreson");
        bmob.findObjects(new FindListener<MoreBean>() {

            @Override
            public void done(List<MoreBean> arg0, BmobException arg1) {
                if (arg1 == null) {
                    onData.onlist(arg0);
                }
            }
        });
    }

    interface OnData {
        void onlist(List<MoreBean> list);
    }
}
