package com.gmsy.bmob;

import cn.bmob.v3.BmobObject;

public class Movies extends BmobObject {
    // 影视标题
    private String title;
    // 影视封面
    private String image;
    // 影视播放地址
    private String plays;
    //播放次数
    private int browse;

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return this.image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getPlays() {
        return this.plays;
    }

    public void setPlays(String plays) {
        this.plays = plays;
    }
}
