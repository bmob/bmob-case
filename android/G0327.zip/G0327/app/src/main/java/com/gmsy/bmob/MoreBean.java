package com.gmsy.bmob;

import cn.bmob.v3.BmobObject;

public class MoreBean extends BmobObject {
    private String img;
    private String title;
    private String js;
    private String url;
    private MoreSon moreson;

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getJs() {
        return js;
    }

    public void setJs(String js) {
        this.js = js;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public MoreSon getMoreSon() {
        return moreson;
    }

    public void setMoreSon(MoreSon moreSon) {
        this.moreson = moreSon;
    }
}