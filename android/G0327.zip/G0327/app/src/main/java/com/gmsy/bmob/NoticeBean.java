package com.gmsy.bmob;

import cn.bmob.v3.BmobObject;

public class NoticeBean extends BmobObject {

    //公告内容
    private String conntent;

    //是否强制弹窗
    private boolean isShow;

    public String getConntent() {
        return this.conntent;
    }

    public void setConntent(String messgae) {
        this.conntent = messgae;
    }

    public void SetIsShow(boolean show) {
        this.isShow = show;
    }

    public boolean getIsShow() {
        return this.isShow;
    }
}