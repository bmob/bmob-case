package com.gmsy.bmob;

import cn.bmob.v3.BmobObject;

public class TopBannerGameBean extends BmobObject {
  // 视频封面
  private String videoimg;

  // 视频播放链接
  private String videoplay;

  // 游戏图标
  private String img;

  // 游戏名称
  private String name;

  // 游戏介绍
  private String jieshao;

  // 下载地址
  private String xiazai;

  public String getVideoimg() {
    return this.videoimg;
  }

  public void setVideoimg(String videoimg) {
    this.videoimg = videoimg;
  }

  public String getVideoplay() {
    return this.videoplay;
  }

  public void setVideoplay(String videoplay) {
    this.videoplay = videoplay;
  }

  public String getImg() {
    return this.img;
  }

  public void setImg(String img) {
    this.img = img;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getJieshao() {
    return this.jieshao;
  }

  public void setJieshao(String jieshao) {
    this.jieshao = jieshao;
  }

  public String getXiazai() {
    return this.xiazai;
  }

  public void setXiazai(String xiazai) {
    this.xiazai = xiazai;
  }
}
