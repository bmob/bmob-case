package com.gmsy.fragment.video;

import android.content.Intent;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import android.os.Bundle;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jzvd.Jzvd;
import com.czj.base.base.BaseFragment;
import com.gmsy.R;
import com.gmsy.activity.WebActivity;
import com.gmsy.bean.WebBean;
import com.gmsy.bmob.GameVideo;
import com.gmsy.bmob.TopBannerGameBean;
import com.gmsy.constant.Constant;
import com.gmsy.databinding.FragmentVideoBinding;
import com.gmsy.fragment.home.HomeViewModel;
import com.gmsy.fragment.home.TopBannerGameAdapter;
import com.gmsy.utils.AutoPlayUtils;
import com.gyf.immersionbar.ImmersionBar;

public class TowVideoFragment extends BaseFragment<FragmentVideoBinding> {

  private VideoViewModel viewmodel;
  private LinearLayoutManager mLayoutManager;
  private GameVideoAdapter topAdapter;

  @Override
  protected void onInitView(Bundle arg0, FragmentVideoBinding arg1, FragmentActivity arg2) {
    ImmersionBar.setTitleBar(this, binding.titlebar);
  }

  @Override
  protected void lazyLoad() {
    viewmodel = new ViewModelProvider(this).get(VideoViewModel.class);
    viewmodel.getTopBannerGame();

    viewmodel.rtTopBannerGameList.observe(
        this,
        list -> {
          mLayoutManager = new LinearLayoutManager(context);
          binding.rv.setLayoutManager(mLayoutManager);
          topAdapter = new GameVideoAdapter(list);
          binding.rv.setAdapter(topAdapter);
        });

    binding.rv.addOnChildAttachStateChangeListener(
        new RecyclerView.OnChildAttachStateChangeListener() {
          @Override
          public void onChildViewAttachedToWindow(View view) {}

          @Override
          public void onChildViewDetachedFromWindow(View view) {
            Jzvd jzvd = view.findViewById(R.id.jz_video);
            if (jzvd != null
                && Jzvd.CURRENT_JZVD != null
                && jzvd.jzDataSource.containsTheUrl(
                    Jzvd.CURRENT_JZVD.jzDataSource.getCurrentUrl())) {
              if (Jzvd.CURRENT_JZVD != null && Jzvd.CURRENT_JZVD.screen != Jzvd.SCREEN_FULLSCREEN) {
                Jzvd.releaseAllVideos();
              }
            }
          }
        });

    binding.rv.addOnScrollListener(
        new RecyclerView.OnScrollListener() {
          @Override
          public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            if (newState == RecyclerView.SCROLL_STATE_IDLE) {
              AutoPlayUtils.onScrollPlayVideo(
                  binding.rv,
                  R.id.jz_video,
                  mLayoutManager.findFirstVisibleItemPosition(),
                  mLayoutManager.findLastVisibleItemPosition());
            }
          }

          @Override
          public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            if (dy != 0) {
              AutoPlayUtils.onScrollReleaseAllVideos(
                  mLayoutManager.findFirstVisibleItemPosition(),
                  mLayoutManager.findLastVisibleItemPosition(),
                  0.2f);
            }
          }
        });
    
    binding.rv.setOnItemClickListener((view,size)->{
      TopBannerGameBean bean = topAdapter.getItemData(size);
          WebBean webbean = new WebBean();
          webbean.setHttp(bean.getXiazai());
          webbean.setTitle(bean.getName());
          // webbean.setJavascript(bean.getJs());
          Intent intent = new Intent(context, WebActivity.class);
          intent.putExtra(Constant.ACTION_WEB_KEY, webbean);
          startActivity(intent);
    });
    
    
    binding.rv.setOnItemChildClickListener(
        (view, size) -> {
          TopBannerGameBean bean = topAdapter.getItemData(size);
          if (view.getId() == R.id.kp2) {
            WebBean webbean = new WebBean();
            webbean.setHttp(bean.getXiazai());
            webbean.setTitle(bean.getName());
            // webbean.setJavascript(bean.getJs());
            Intent intent = new Intent(context, WebActivity.class);
            intent.putExtra(Constant.ACTION_WEB_KEY, webbean);
            startActivity(intent);
          }
        });
  }
}
