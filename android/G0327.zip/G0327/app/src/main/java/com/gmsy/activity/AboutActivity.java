package com.gmsy.activity;

import android.os.Bundle;

import com.czj.base.base.BaseActivity;
import com.gyf.immersionbar.ImmersionBar;

public class AboutActivity extends BaseActivity<com.gmsy.databinding.ActivityAboutBinding> {

    @Override
    protected void initActivity(Bundle bundle) {
        ImmersionBar.setTitleBar(this, binding.title);
    }
}