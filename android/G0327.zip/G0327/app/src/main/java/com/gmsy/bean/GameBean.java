package com.gmsy.bean;

public class GameBean {

  private String title;
  private String http;
  private String imag;

  public String getTitle() {
    return this.title;
  }

  public void setTitle(java.lang.String title) {
    this.title = title;
  }

  public String getHttp() {
    return this.http;
  }

  public void setHttp(java.lang.String http) {
    this.http = http;
  }

  public String getImag() {
    return this.imag;
  }

  public void setImag(java.lang.String imag) {
    this.imag = imag;
  }
}
