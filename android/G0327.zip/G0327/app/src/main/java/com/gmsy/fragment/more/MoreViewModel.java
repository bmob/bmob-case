package com.gmsy.fragment.more;

import androidx.lifecycle.MutableLiveData;

import com.gmsy.base.BaseViewModel;
import com.gmsy.bmob.MoreBean;
import com.gmsy.bmob.MoreSon;

import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

public class MoreViewModel extends BaseViewModel {

    private MutableLiveData<List<MoreBean>> MoreLiveData;
    private MutableLiveData<List<MoreSon>> listMutableLiveData;

    //查询列表
    public void getMorelist() {
        BmobQuery<MoreBean> bmob = new BmobQuery<>();
        bmob.findObjects(new FindListener<MoreBean>() {

            @Override
            public void done(List<MoreBean> arg0, BmobException arg1) {
                if (arg1 == null) {
                    getMoreLiveData().setValue(arg0);
                }
            }
        });
    }

    //查询栏目
    public void getMoreSonList() {
        BmobQuery<MoreSon> bmobQuery = new BmobQuery<>();
        bmobQuery.findObjects(new FindListener<MoreSon>() {
            @Override
            public void done(List<MoreSon> list, BmobException e) {
                if (e == null) {
                    getMoreSonLiveData().setValue(list);
                }
            }
        });
    }


    public MutableLiveData<List<MoreBean>> getMoreLiveData() {
        return getMutableLiveDataList(MoreBean.class);
    }

    public MutableLiveData<List<MoreSon>> getMoreSonLiveData() {
        return getMutableLiveDataList(MoreSon.class);
    }


}
