package com.gmsy.bean;

import java.io.Serializable;

public class WebBean implements Serializable {
  private String title;
  private String http;
  private String javascript;
  private boolean isshow = false;

  public String getTitle() {
    return this.title;
  }

  public void setTitle(java.lang.String title) {
    this.title = title;
  }

  public String getHttp() {
    return this.http;
  }

  public void setHttp(java.lang.String http) {
    this.http = http;
  }

  public String getJavascript() {
    return this.javascript;
  }

  public void setJavascript(java.lang.String javascript) {
    this.javascript = javascript;
  }

  public boolean getIsshow() {
    return this.isshow;
  }

  public void setIsshow(boolean isshow) {
    this.isshow = isshow;
  }
}
