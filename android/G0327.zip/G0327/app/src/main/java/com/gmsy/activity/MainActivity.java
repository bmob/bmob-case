package com.gmsy.activity;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import cn.jzvd.Jzvd;
import com.czj.base.adapter.PagerAdapter2;
import com.czj.base.base.BaseActivity;
import com.gmsy.R;
import com.gmsy.databinding.ActivityMainBinding;
import com.gmsy.fragment.game.GameFragment;
import com.gmsy.fragment.home.HomeFragment;
import com.gmsy.fragment.more.MoreFragment;
import com.gmsy.fragment.video.TowVideoFragment;
import com.gmsy.fragment.video.VidoeFragment;
import com.hjq.toast.ToastUtils;
import com.itsaky.androidide.logsender.LogSender;
import com.kongzue.tabbar.Tab;

import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BaseActivity<ActivityMainBinding> {

  @Override
  protected void initActivity(Bundle arg0) {
    统计记录();
    // LogSender.startLogging(this);
    initViewPager();
    initTabBarView();
  }

  private void initViewPager() {
    binding.viewpager.setAdapter(
        new PagerAdapter2(getSupportFragmentManager(), getLifecycle(), initFragment()));
    binding.viewpager.setUserInputEnabled(false);
    binding.viewpager.setOffscreenPageLimit(3);
  }

  private void initTabBarView() {
    binding.barview.setTab(initIcon());
    binding.barview.setOnTabChangeListener(
        (v, i) -> {
          binding.viewpager.setCurrentItem(i, false);
          return false;
        });
  }

  private List<Tab> initIcon() {
    List<Tab> tab = new ArrayList<>();
    tab.add(
        new Tab(this, "首页", R.mipmap.icon_tab_home_unselect)
            .setFocusIcon(this, R.mipmap.icon_tab_home_selected));
    tab.add(
        new Tab(this, "视频", R.mipmap.icon_tab_video_unselect)
            .setFocusIcon(this, R.mipmap.icon_tab_video_selected));
    tab.add(new Tab(this, "免费", R.mipmap.icon_game).setFocusIcon(this, R.mipmap.icongame));
    tab.add(
        new Tab(this, "推荐", R.mipmap.icon_tab_more_unselect)
            .setFocusIcon(this, R.mipmap.icon_tab_more_selected));

    return tab;
  }

  private List<Fragment> initFragment() {
    List<Fragment> fragments = new ArrayList<>();
    fragments.clear();
    fragments.add(new HomeFragment());
    //fragments.add(new VidoeFragment());
    fragments.add(new TowVideoFragment());
    fragments.add(new GameFragment());
    fragments.add(new MoreFragment());
    return fragments;
  }

  private void 统计记录() {
    OkGo.<String>post("http://phplua.top/usertoj/caozuser/toj.php?json={\"appid\":\"243\"}")
        .execute(
            new StringCallback() {
              @Override
              public void onSuccess(Response<String> arg0) {
                // ToastUtils.show(arg0.body());
              }
            });
  }

  @Override
  public void onBackPressed() {
    if (Jzvd.backPress()) {
      return;
    }
    super.onBackPressed();
  }

  @Override
  protected void onPause() {
    super.onPause();
    Jzvd.releaseAllVideos();
  }
}
