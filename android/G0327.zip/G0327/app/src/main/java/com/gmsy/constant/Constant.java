package com.gmsy.constant;

public class Constant {
    //Bmob id
    public static String Bmob_APPId = "b88463dd879b630e51a28c97428d9ad1";
    
    //bmob域名
    public static String Bmob_HTTP = "http://qing.8gmt.xyz/8/";
    
    
    //bmob公告id
    public static String Bmob_NoticID = "8ec2f664a1";
    
    //Bmob更新id
    public static String Bmob_UpdateID = "0f24737763";
    
    //街机游戏域名（切勿删除)
    public static String Game_Id = "https://www.yikm.net";
    
    // WebActivity传值常量
    public static String ACTION_WEB_KEY = "webkey";
    
    
    //淘宝店铺
    public static String Taobao = "https://h5.m.taobao.com/awp/core/detail.htm?ft=t&id=675296049557";
    
    
}
