package com.gmsy.fragment.home;

import android.widget.ImageView;
import cn.jzvd.JzvdStd;
import com.bumptech.glide.Glide;
import com.gmsy.R;
import com.gmsy.bmob.TopBannerGameBean;
import java.util.List;
import me.jingbin.library.adapter.BaseByViewHolder;
import me.jingbin.library.adapter.BaseRecyclerAdapter;

public class TopBannerGameAdapter extends BaseRecyclerAdapter<TopBannerGameBean> {

  public TopBannerGameAdapter(List<TopBannerGameBean> list) {
    super(R.layout.item_topbannergame, list);
  }

  @Override
  protected void bindView(
      BaseByViewHolder<TopBannerGameBean> holder, TopBannerGameBean bean, int arg2) {
    JzvdStd jzvdStd = holder.getView(R.id.jz_video);
    jzvdStd.setUp(bean.getVideoplay(), "");
    Glide.with(jzvdStd).load(bean.getVideoimg()).into(jzvdStd.posterImageView);

    ImageView iv = holder.getView(R.id.tx2);
    Glide.with(iv).load(bean.getImg()).into(iv);
    holder.setText(R.id.wb1, bean.getName());
    holder.setText(R.id.wb2, bean.getJieshao());

    holder.addOnClickListener(R.id.kp2);
  }
}
