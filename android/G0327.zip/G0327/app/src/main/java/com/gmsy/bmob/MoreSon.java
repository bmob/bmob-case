package com.gmsy.bmob;

import cn.bmob.v3.BmobObject;

public class MoreSon extends BmobObject {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
