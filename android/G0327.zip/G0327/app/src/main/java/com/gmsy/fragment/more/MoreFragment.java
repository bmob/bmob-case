package com.gmsy.fragment.more;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.czj.base.base.BaseFragment;
import com.gmsy.activity.SettingActivity;
import com.gmsy.activity.WebActivity;
import com.gmsy.bean.WebBean;
import com.gmsy.bmob.MoreBean;
import com.gmsy.constant.Constant;
import com.gmsy.databinding.FragmentMoreBinding;
import com.gyf.immersionbar.ImmersionBar;
import com.hjq.bar.OnTitleBarListener;
import com.hjq.bar.TitleBar;

public class MoreFragment extends BaseFragment<FragmentMoreBinding> {

    private MoreViewModel viewmodel;

    @Override
    protected void onInitView(Bundle arg0, FragmentMoreBinding arg1, FragmentActivity arg2) {
        ImmersionBar.setTitleBar(this, binding.titlebar);
    }

    @Override
    protected void lazyLoad() {
        viewmodel = new ViewModelProvider(this).get(MoreViewModel.class);
        viewmodel.getMoreSonList();
        //viewmodel.getMorelist();
        initLiveData();
    }

    private void initLiveData() {
        viewmodel.getMoreLiveData().observe(this, (list) -> {
            binding.rv.setLayoutManager(new GridLayoutManager(context, 4));
            MoreAdapter adapter = new MoreAdapter(list);
            binding.rv.setAdapter(adapter);
            binding.rv.setOnItemClickListener((v, i) -> {
                        MoreBean bean = adapter.getItemData(i);
                        WebBean webbean = new WebBean();
                        webbean.setTitle(bean.getTitle());
                        webbean.setHttp(bean.getUrl());
                        webbean.setJavascript(bean.getJs());
                        Intent intent = new Intent();
                        intent.setClass(context, WebActivity.class);
                        intent.putExtra(Constant.ACTION_WEB_KEY, webbean);
                        startActivity(intent);
                    });
        });

        viewmodel.getMoreSonLiveData().observe(this,(list)->{
            binding.rv.setLayoutManager(new LinearLayoutManager(context));
            MoreSonAdapter adapter = new MoreSonAdapter(context,list);
            binding.rv.setAdapter(adapter);
        });

        binding.titlebar.setOnTitleBarListener(new OnTitleBarListener() {
            @Override
            public void onRightClick(TitleBar titleBar) {
                Intent intent = new Intent(context, SettingActivity.class);
                startActivity(intent);
            }
        });
    }
}
