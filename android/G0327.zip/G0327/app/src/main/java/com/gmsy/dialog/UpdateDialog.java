package com.gmsy.dialog;

import android.content.Context;
import android.view.View;

import androidx.appcompat.widget.AppCompatTextView;

import com.gmsy.R;
import com.gmsy.bmob.UpdateBean;
import com.gmsy.utils.WebTools;
import com.lxj.xpopup.core.CenterPopupView;

public class UpdateDialog extends CenterPopupView {

    private UpdateBean bean;
    private AppCompatTextView tv_update_name, tv_update_content, tv_update_update, tv_update_close;

    public UpdateDialog(Context ctx, UpdateBean bean) {
        super(ctx);
        this.bean = bean;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.dialog_update;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        initView();
        initDate();
    }

    private void initDate() {
        tv_update_name.setText(bean.getVersion());
        tv_update_content.setText(bean.getContent());
        if (bean.getIsshow()) {
            tv_update_close.setVisibility(View.GONE);
        }
        tv_update_update.setOnClickListener((v) -> {
            WebTools.openLink(getContext(), bean.getDownload());
        });
        tv_update_close.setOnClickListener((v) -> {
            dismiss();
        });

    }

    private void initView() {
        tv_update_name = findViewById(R.id.tv_update_name);
        tv_update_content = findViewById(R.id.tv_update_content);
        tv_update_update = findViewById(R.id.tv_update_update);
        tv_update_close = findViewById(R.id.tv_update_close);
    }

}
