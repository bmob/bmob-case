package com.gmsy.fragment.more;

import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.gmsy.R;
import com.gmsy.bmob.MoreBean;

import java.util.List;

import me.jingbin.library.adapter.BaseByViewHolder;
import me.jingbin.library.adapter.BaseRecyclerAdapter;

public class MoreAdapter extends BaseRecyclerAdapter<MoreBean> {

    public MoreAdapter(List<MoreBean> list) {
        super(R.layout.item_more, list);
    }

    @Override
    protected void bindView(BaseByViewHolder<MoreBean> holder, MoreBean bean, int arg2) {
        holder.setText(R.id.tv_title, bean.getTitle());
        ImageView iv = holder.getView(R.id.iv_image);
        Glide.with(iv).load(bean.getImg()).transform(new RoundedCorners(15)).into(iv);
    }
}
