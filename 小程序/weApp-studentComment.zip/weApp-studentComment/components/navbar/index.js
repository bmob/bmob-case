var app = getApp();
Component({
  properties: {
    parameter: {
      type: Object,
      value: {
        title: '',
        home: 0,
        fixed: 0,
        hideBack: 0,
        gray: 1
      },
    }
  },
  data: {
    navH: "",

    className: "",
    showPicker: false,
    selColor: '#42A0FF',
    actions: [
      // {
      //   name: '',
      //   color: 
      // }
    ],
  },
  ready: function () {
    // console.log('ready!!', this.properties.parameter.title)
    this.setClass();
    var pages = getCurrentPages();
    if (pages.length <= 1) this.setData({
      'parameter.return': 1
    });
  },
  attached: function () {
    this.setData({
      navH: app.globalData.navHeight,
      menuHeight: app.globalData.menuHeight,
      menuTop: app.globalData.menuTop,
    });
  },
  pageLifetimes: {
    show() {
      if (!this.data.parameter.hideBack) return;
      if (this.data.parameter.hideNav) return;
      var myClassName = wx.Apis.get('className');
      if (myClassName) {
        this.setData({
          className: myClassName
        })
        return;
      } else {
        this.onRefreshName()
      }
      // console.log('nav getSchoolList')
      // wx.Apis.User.getSchoolList(
      //   (code, data) => {
      //     this.setData({
      //       loading: false
      //     })
      //     if (code === 0) {
      //       const {
      //         school_open_id
      //       } = wx.Apis.isLogin()
      //       console.log('school_open_id:', school_open_id)
      //       data = (data || []).map(e => {
      //         e.str = JSON.stringify(e)
      //         e.isMy = e.school_open_id === school_open_id
      //         if (e.isMy) {
      //           e.color = this.data.selColor
      //           this.setData({
      //             className: e.name
      //           })
      //           wx.Apis.set('className', e.name)
      //         }
      //         return e;
      //       })
      //       // data.push({
      //       //   name: '取消'
      //       // })
      //       console.log('actions', data)
      //       this.setData({
      //         actions: data
      //       })
      //     }
      //   })
    }
  },
  methods: {
    onRefreshName() {
      wx.Apis.User.getInviteCode((code, data, message) => {
        if (code == 0) {
          wx.Apis.set('className', data.name);
          this.setData({
            className: data.name
          })
        }
      })
    },
    onClickTitle() {
      this.properties.parameter.onClickTitle && this.properties.parameter.onClickTitle()
    },
    onClickTab(e) {
      this.properties.parameter.onClickTab && this.properties.parameter.onClickTab(e.currentTarget.dataset.i)
    },
    navBack(event) {
      const that = this
      if (event != "force" &&
        this.data.parameter.onReturn &&
        !this.data.parameter.onReturn(function () {
          that.navBack('force')
        }))
        return
      this.data.parameter.return == 1 ? this.home() : this.return()
    },
    return: function () {
      wx.navigateBack();
    },
    home: function () {
      getApp().goHome()
    },
    setClass: function () {
      var color = '';
      switch (this.data.parameter.class) {
        case "0":
        case 'on':
          color = 'on'
          break;
        case '1':
        case 'black':
          color = 'black'
          break;
        case '2':
        case 'gray':
          color = 'gray'
          break;
        default:
          break;
      }
      this.setData({
        'parameter.class': color
      })
    },

    showAction() {
      wx.navigateTo({
        url: '/pages/switch_school/index',
      })
      // this.setData({
      //   showPicker: true
      // })
    },
    onCancel() {
      this.setData({
        showPicker: false
      });
    },
    onSelect(e) {
      console.log('onSelect', e)
      this.setData({
        showPicker: false
      });
      const item = e.detail;
      if (item.isMy || !item.school_open_id) return
      wx.Apis.User.switch_school(item.school_open_id, ((code) => {
        if (code === 0) {
          wx.Common.toast("切换成功")
          var actions = this.data.actions;
          actions = actions.map(e => {
            e.isMy = item.school_open_id === e.school_open_id
            e.color = e.isMy ? this.data.selColor : ''
            return e;
          })
          this.setData({
            actions,
            className: item.name
          })
          wx.Apis.set('className', item.name)
          this.data.parameter.refreshFunc && this.data.parameter.refreshFunc()
        }
      }))
    },
  }
})