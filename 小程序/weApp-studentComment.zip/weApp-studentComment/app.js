// app.js

const Bmob = require('/utils/Bmob-2.4.0.min.js')
Bmob.initialize("ca79e5ac860f0ccf6729c3d366ee959e", "61e06ffe2e09df6c8e2bb1996a3aa013", "11c0ceca1cfabfbe4d735ee84599cdbb");
wx.Bmob = Bmob;

App({
  onLaunch() {
    // // 展示本地存储能力
    // const logs = wx.getStorageSync('logs') || []
    // logs.unshift(Date.now())
    // wx.setStorageSync('logs', logs)

    // // 登录
    // wx.login({
    //   success: res => {
    //     // 发送 res.code 到后台换取 openId, sessionKey, unionId
    //   }
    // })


    wx.getSystemInfo({
      success: res => {
        console.log('getSystemInfo res', res)

        // 胶囊按钮位置信息
        const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
        this.globalData.menuTop = menuButtonInfo.top;
        this.globalData.menuHeight = menuButtonInfo.height;
        this.globalData.menuRight = res.screenWidth - menuButtonInfo.right;

        console.log('menuButtonInfo', menuButtonInfo)

        // 导航栏高度 = 状态栏高度 + 44
        this.globalData.navHeight = menuButtonInfo.bottom + (res.model == 'iPad' ? 18 : 12);

        if (res.model.indexOf('iPhone X') > -1) //iphonex，xr，xs
          this.globalData.fullScreen = true;
        this.globalData.isIOS = res.platform === "ios" // || res.platform === "devtools"

        console.log('globalData', this.globalData)
      },
      fail(err) {
        console.log(err);
      }
    })
  },
  globalData: {
    userInfo: null
  }
})