// pages/home/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    menuTop: 20,
    list: [],
    content: '减轻您的工作，一键生成各种评语',

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      menuTop: getApp().globalData.menuTop
    })
    this.getSetting()
    this.fetchData()

    // 在页面中定义插屏广告 
    let interstitialAd = null
    // 在页面onLoad回调事件中创建插屏广告实例 
    if (wx.createInterstitialAd) {
      interstitialAd = wx.createInterstitialAd({
        adUnitId: 'adunit-7e030a22fccfb201'
      })
      interstitialAd.onLoad(() => {})
      interstitialAd.onError((err) => {})
      interstitialAd.onClose(() => {})
      this.data.interstitialAd = interstitialAd
      this.showAd()
    }
  },

  showAd() {
    // 在适合的场景显示插屏广告 
    if (this.data.interstitialAd) {
      this.data.interstitialAd.show().catch((err) => {
        console.error(err)
      })
    }
  },

  go() {
    wx.navigateToMiniProgram({
      appId: 'wxf8801f7c6a079792'
    })
  },

  fetchData() {
    wx.showLoading({
      title: '加载中',
    })
    const query = wx.Bmob.Query("Theme");
    query.order('row')
    query.find().then(res => {
      wx.hideLoading()
      var list = [];
      var lastRow;
      res.forEach(e => {
        const {
          row
        } = e;
        if (row == lastRow) {
          list[list.length - 1].push(e)
        } else {
          list.push([e])
          lastRow = row
        }
      })
      list.forEach(arr => {
        arr.sort((a, b) => {
          return a.column - b.column
        })
      })
      this.setData({
        list
      })
      this.getList1()
    }).catch(err => {
      console.error(err)
      wx.hideLoading()
      wx.showModal({
        title: '提示',
        content: '加载失败，请检查网络',
        success: (res) => {
          if (res.confirm) {
            this.getSetting()
            this.fetchData()
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        },
        confirmText: '重试',
      })
    })
  },

  onClickItem(e) {
    const item = this.data.list1[e.currentTarget.dataset.i]
    wx.navigateTo({
      url: `/pages/detail/index?id=${item.objectId}`
    })
  },

  getSetting() {
    const query = wx.Bmob.Query("CommentSetting");
    query.equalTo('type', '==', 1)
    query.limit(1)
    query.find().then(res => {
      if (res.length)
        this.setData({
          content: res[0].content
        })
    }).catch(err => {
      console.error(err)
    })
  },

  getList1() {
    return
    const query = wx.Bmob.Query("Ppt");
    query.equalTo('isShow', '==', true)
    query.order("-isRecommend", "weight");
    query.limit(10)
    this.setData({
      loading: true
    })
    query.find().then(res => {
      wx.hideLoading()
      this.setData({
        list1: res,
        loading: false,
      })
    }).catch(err => {
      console.error(err)
      wx.hideLoading()
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})