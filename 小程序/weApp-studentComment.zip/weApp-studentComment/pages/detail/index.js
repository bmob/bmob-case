// pages/detail/index.js
import Toast from '@vant/weapp/toast/toast';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    parameter: {
      title: ""
    },
    obj: {},
    setting: [10, 5, 4, "长按二维码图片，进入中国移动云盘免费下载PPT模板", "以上资源来自于互联网网友免费分享，如有侵权，请联系客服下架。"],
    fullScreen: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      id: options.id,
      fullScreen: getApp().globalData.fullScreen
    })
    this.getData()
  },

  onClickImg(e) {
    wx.previewImage({
      urls: this.data.obj.images,
      current: e.currentTarget.dataset.u
    })
  },

  addPptDownLoadCount() {
    const query = wx.Bmob.Query('Ppt')
    query.get(this.data.id).then(res => {
      res.increment('count')
      res.save()
    }).catch(err => {
      console.error(err)
    })
  },

  addCountDownLoad(i = 1) {
    // console.log('addCountDownLoad', i)
    // const query = wx.Bmob.Query('_User')
    // query.get(wx.Bmob.User.current().objectId).then(res => {
    //   res.set('lastDownloadDate', wx.Common.formatTime(new Date(), true))
    //   if (res == 0)
    //     res.set('countDownload', i)
    //   else
    //     res.increment('countDownload', i)
    //   res.save()
    // }).catch(err => {
    //   console.error(err)
    // })
  },

  download() {
    const {
      obj
    } = this.data;
    if (obj.qrcode) {
      this.setData({
        showDialog: true
      })
      this.addCountDownLoad()
      this.addPptDownLoadCount()
      return
    }
    if (!obj.url) {
      wx.Common.toast('下载失败，暂无链接')
      return;
    }
    wx.showLoading({
      title: '下载中',
    })
    const that = this;
    wx.downloadFile({
      url: obj.url,
      success(res) {
        wx.hideLoading()
        console.log('download res', res)
        if (res.statusCode === 200) {
          wx.showToast({
            title: '下载成功',
            icon: 'success'
          })
          that.addCountDownLoad()
          that.addPptDownLoadCount()
          // wx.shareFileMessage({
          //   filePath: res.tempFilePath,
          //   fileName: obj.title + '.xlsx',
          //   success() {},
          //   fail: console.error,
          // })
          // return;
          const manage = wx.getFileSystemManager();
          manage.saveFile({
            tempFilePath: res.tempFilePath,
            success: function (res) {
              console.log('save res', res)
              wx.hideLoading()

              var filePath = res.savedFilePath;
              if (filePath.indexOf('.bin' > -1)) {
                let pathNew = `${wx.env.USER_DATA_PATH}/1.pptx`
                try {
                  const res = manage.renameSync(
                    filePath,
                    pathNew
                  )
                  filePath = pathNew;
                  console.log(res)
                } catch (e) {
                  console.error(e)
                }
              }
              console.log('filePath', filePath)
              wx.openDocument({
                filePath,
                success: function (res) {
                  console.log('打开文档成功')
                },
                fail: function () {
                  console.log('打开失败');
                }
              })
            },
            fail(err) {
              wx.hideLoading()
              console.error(err)
              wx.Common.toast('保存失败:', err.errMsg)
            }
          });
        } else {
          console.error(res)
          wx.Common.toast('下载失败' + res.statusCode)
        }
      },
      fail(err) {
        wx.hideLoading()
        console.error(err)
        wx.Common.toast('下载失败:' + err.errMsg)
      }
    })

  },

  getSetting() {
    const query = wx.Bmob.Query("CommentSetting");
    query.order('-updatedAt')
    query.limit(1)
    query.equalTo('type', '==', 2)
    query.find().then(res => {
      if (res.length && res[0].content) {
        this.setData({
          setting: res[0].content.split(',')
        })
      }
    })
  },

  getData() {
    wx.showLoading({
      title: '加载中',
    })
    const query = wx.Bmob.Query('Ppt');
    query.get(this.data.id).then(res => {
      this.getSetting()
      wx.hideLoading()
      res.images = res.images ? res.images.split(',') : []
      this.setData({
        obj: res,
        'parameter.title': res.title
      })
      wx.setNavigationBarTitle({
        title: res.title,
      })
    }).catch(err => {
      console.error(err)
      wx.hideLoading()
      wx.showModal({
        title: '提示',
        content: '加载失败，请检查网络',
        success: (res) => {
          if (res.confirm) {
            this.getData()
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        },
        confirmText: '重试',
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    this.addCountDownLoad((parseInt(this.data.setting[1]) * -1) || -5)
  }
})