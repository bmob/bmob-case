// pages/comment/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    parameter: {
      title: "评语生成"
    },
    tid: '',
    index: 0,
    item: {},
    str: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      tid: options.tid
    })
    if (options.str)
      this.setData({
        str: options.str
      })
    else
      this.fetchData()

    // 在页面中定义激励视频广告 
    let videoAd = null
    // 在页面onLoad回调事件中创建激励视频广告实例 
    if (wx.createRewardedVideoAd) {
      videoAd = wx.createRewardedVideoAd({
        adUnitId: 'adunit-2b4bf351dd8648f1'
      })
      videoAd.onLoad(() => {})
      videoAd.onError((err) => {
        console.error('videoAd err', err)
        wx.Common.toast('视频广告加载失败')
      })
      videoAd.onClose((status) => {
        // if (status && status.isEnded || status === undefined) {
        //   // 正常播放结束，下发奖励
        //   this.addCount()
        // } else {
        //   wx.Common.toast('播放中途退出，获取奖励失败')
        // }
      })
      this.data.videoAd = videoAd
      this.openVideoAd()
    }
  },

  openVideoAd() {
    console.log('打开激励视频');
    if (this.data.videoAd) {
      this.data.videoAd.show().catch(err => {
        // 失败重试
        this.data.videoAd.load().then(() => this.data.videoAd.show())
      })
    }
  },

  onInput(e) {
    this.setData({
      str: e.detail.value
    })
  },

  fetchData() {
    wx.showLoading({
      title: '加载中',
    })
    var index = this.data.index
    const query = wx.Bmob.Query("Comment");
    query.equalTo('theme', '==', wx.Bmob.Pointer('Theme').set(this.data.tid))
    query.order('-createdAt')
    query.skip(index)
    query.limit(1)
    query.find().then(res => {
      wx.hideLoading()
      if (res && res.length) {
        this.setData({
          item: res[0],
          str: res[0].content || '',
          index: ++index
        })
      } else if (index <= 1) {
        wx.showToast({
          title: index == 0 ? '暂无数据' : '没有更多了',
          icon: 'none'
        })
      } else {
        this.data.index = 0
        this.fetchData()
      }
    }).catch(err => {
      console.error(err)
      wx.hideLoading()
      wx.showModal({
        title: '提示',
        content: '加载失败，请检查网络',
        success: (res) => {
          if (res.confirm) {
            this.fetchData()
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        },
        confirmText: '重试',
      })
    })
  },

  copy() {
    if (this.data.item.content)
      wx.setClipboardData({
        data: this.data.str,
        success(res) {
          // wx.getClipboardData({
          //   success(res) {
          //     console.log(res.data) // data
          //   }
          // })
        }
      })
  },

  back() {
    if (getCurrentPages().length > 1)
      wx.navigateBack()
    else
      wx.reLaunch({
        url: '/pages/index/index',
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    const {
      tid,
      str
    } = this.data;
    var path = `/pages/comment/index?tid=${tid}&str=${str}`
    console.log(path)
    return {
      title: '学生评语大全',
      path
    }
  }
})