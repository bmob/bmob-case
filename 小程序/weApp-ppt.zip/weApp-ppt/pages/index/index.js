Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabs: [],
    active: 0,
    list: [],
    page: 0,
    limit: 10
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getTabs()
  },

  onClickItem(e) {
    const item = this.data.list[e.currentTarget.dataset.i]
    wx.navigateTo({
      url: `/pages/detail/index?id=${item.objectId}`
    })
  },

  onChange(e) {
    this.setData({
      active: e.detail.index
    })
    this.getList(true)
  },

  getTabs() {
    wx.showLoading({
      title: '加载中',
    })
    const query = wx.Bmob.Query("PptType");
    query.equalTo('isHide', '!=', true)
    query.order('weight')
    query.find().then(res => {
      wx.hideLoading()
      this.setData({
        tabs: res
      })
      this.getList(true)
    }).catch(err => {
      console.error(err)
      wx.hideLoading()
      wx.showModal({
        title: '提示',
        content: '加载失败，请检查网络',
        success: (res) => {
          if (res.confirm) {
            this.getTabs()
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        },
        confirmText: '重试',
      })
    })
  },

  getList(isRefresh) {
    if (this.data.tabs.length == 0) return;
    const typeId = this.data.tabs[this.data.active].objectId;
    const query = wx.Bmob.Query("Ppt");
    var page = isRefresh ? 0 : this.data.page;
    query.equalTo('isShow', '==', true)
    query.equalTo('type', '==', wx.Bmob.Pointer('PptType').set(typeId))
    query.order("-isRecommend", "weight");
    query.limit(this.data.limit)
    query.skip(page * this.data.limit)
    this.setData({
      loading: true
    })
    query.find().then(res => {
      wx.hideLoading()
      this.setData({
        list: isRefresh ? res : this.data.list.concat(res),
        loading: false,
        page: ++page
      })
    }).catch(err => {
      console.error(err)
      wx.hideLoading()
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.getList()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})