// 返回统一的回调处理器
function toast(sms, icon = 'none', t = 1500) {
  console.log('[toast]', sms);
  if ((typeof sms) == 'object') {
    try {
      sms = JSON.stringify(sms);
    } catch (err) {}
  }
  if (sms.length > 35) {
    showModal(sms)
    return
  }
  wx.showToast({
    title: sms,
    icon: icon,
    duration: t
  })
}

function formatTime(date, isShort, s = '-') {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  var res = [year, month, day].map(formatNumber).join(s);
  if (!isShort)
    res += (' ' + [hour, minute, second].map(formatNumber).join(':'));
  return res;
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

module.exports.toast = toast;
module.exports.formatTime = formatTime;