package com.example.removewatermarkkotlin

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import cn.bmob.v3.AsyncCustomEndpoints
import cn.bmob.v3.Bmob
import cn.bmob.v3.exception.BmobException
import cn.bmob.v3.listener.CloudCodeListener
import org.json.JSONException
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var videoView: VideoView
    private lateinit var layoutResult: ConstraintLayout
    private lateinit var ivPlay: ImageView
    private lateinit var etLink: EditText
    private var videoUrl: String? = null
    private var fileHash: String? = null
    private val TAG = "bmob"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Bmob.initialize(this, "788fe53baa134997272e07603a0c6d0c")

        layoutResult = findViewById<ConstraintLayout>(R.id.cl_result)
        videoView = findViewById(R.id.vv_video)
        ivPlay = findViewById(R.id.iv_play)
        etLink = findViewById(R.id.et_link)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (videoView != null) {
            videoView.suspend()
        }
    }

    /**
     * 提交视频原链接
     * @param view
     */
    fun onSubmit(view: View?) {
        // test: https://v.douyin.com/DwCd21X/
        val url = etLink.text.toString()
        if (url.isEmpty()) {
            Toast.makeText(applicationContext, "请输入抖音口令或者链接", Toast.LENGTH_SHORT).show()
            return
        }

        val params = JSONObject()
        params.put("url", url)
        val ace = AsyncCustomEndpoints()
        ace.callEndpoint("douyin", params, object : CloudCodeListener() {
            override fun done(o: Any, e: BmobException?) {
                if (e == null) {
                    val result = o.toString()
                    if (result.startsWith("{") && result.endsWith("}")) {
                        // 成功
                        Log.d(TAG, result)
                        try {
                            val jsonObject = JSONObject(result)
                            fileHash = jsonObject.getString("fileHash")
                            videoUrl = jsonObject.optString("video")
                            initVideoPath(videoUrl!!)
                            layoutResult.visibility = View.VISIBLE
                        } catch (ex: JSONException) {
                            ex.printStackTrace()
                        }
                    } else {
                        Log.e(TAG, result)
                        // 失败
                        Toast.makeText(applicationContext, result, Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e(TAG, e.message.toString())
                }
            }
        })
    }

    /**
     * 复制去除水印后的视频链接
     * @param view
     */
    fun onCopyLink(view: View?) {
        //获取剪贴板管理器：
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        // 创建普通字符型ClipData
        val mClipData = ClipData.newPlainText("Label", videoUrl)
        // 将ClipData内容放到系统剪贴板里。
        cm.setPrimaryClip(mClipData)
        Toast.makeText(this, "复制成功", Toast.LENGTH_SHORT).show()
    }

    /**
     * 保存去除水印后的视频链接
     * @param view
     */
    fun onSaveVideo(view: View?) {
        Log.d(TAG, "onSaveVideo: $videoUrl")
        val f = File(
            getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
            "$fileHash.mp4"
        )
        if (f.exists()) {
            f.delete()
        }
        Thread {
            var inputStream: InputStream? = null
            var fileOutputStream: FileOutputStream? = null
            try {
                val url = URL(videoUrl)
                val con = url.openConnection() as HttpURLConnection
                con.requestMethod = "GET"
                con.connectTimeout = 1000 * 6
                if (con.responseCode == 200) {
                    inputStream = con.inputStream
                    fileOutputStream = FileOutputStream(f)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        FileUtils.copy(inputStream, fileOutputStream)
                    } else {
                        //读取长度
                        var len = 0
                        // 下载长度大小
                        var count = 0
                        // 缓存
                        val buf = ByteArray(1024 * 2)
                        while (inputStream.read(buf).also { len = it } != -1) {
                            count += len
                            fileOutputStream.write(buf, 0, len)
                        }
                    }
                    fileOutputStream.close()
                    inputStream.close()
                    videoSaveToNotifyGalleryToRefreshWhenVersionGreaterQ(applicationContext, f)
                    Log.d(TAG, "downloadVideo: 下载成功")
                    Looper.prepare()
                    Toast.makeText(applicationContext, "保存成功", Toast.LENGTH_SHORT).show()
                    Looper.loop()
                } else {
                    Log.d(TAG, "downloadVideo: 下载失败")
                }
            } catch (e: IOException) {
                e.printStackTrace()
            } finally {
                try {
                    fileOutputStream?.close()
                } catch (e: IOException) {
                }
                try {
                    inputStream?.close()
                } catch (e: IOException) {
                }
            }
        }.start()
    }

    fun onPlayOrPause(view: View?) {
        if (videoView == null) {
            return
        }
        if (!videoView!!.isPlaying) {
            videoView!!.start() // 播放
            ivPlay!!.visibility = View.GONE
        } else {
            videoView!!.pause() // 暂停
            ivPlay!!.visibility = View.VISIBLE
        }
    }

    private fun initVideoPath(videoUrl: String) {
        Log.d(TAG, "initVideoPath: $videoUrl")
        videoView.setVideoURI(Uri.parse(videoUrl))
        videoView.seekTo(1) //**调整从第一毫秒进行播放**
    }

    private fun videoSaveToNotifyGalleryToRefreshWhenVersionGreaterQ(
        context: Context,
        destFile: File
    ) {
        val values = ContentValues()
        val uriSavedVideo: Uri?
        uriSavedVideo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies")
            values.put(MediaStore.Video.Media.TITLE, destFile.name)
            values.put(MediaStore.Video.Media.DISPLAY_NAME, destFile.name)
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            values.put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
            values.put(MediaStore.Video.Media.DATA, destFile.absolutePath)
            val collection =
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            context.contentResolver.insert(collection, values)
        } else {
            values.put(MediaStore.Video.Media.TITLE, destFile.name)
            values.put(MediaStore.Video.Media.DISPLAY_NAME, destFile.name)
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            values.put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
            values.put(MediaStore.Video.Media.DATA, destFile.absolutePath)
            context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.put(MediaStore.Video.Media.DATE_TAKEN, System.currentTimeMillis())
            values.put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val pfd: ParcelFileDescriptor?
        try {
            pfd = context.contentResolver.openFileDescriptor(uriSavedVideo!!, "w")
            val out = FileOutputStream(pfd!!.fileDescriptor)
            val `in` = FileInputStream(destFile)
            val buf = ByteArray(8192)
            var len: Int
            while (`in`.read(buf).also { len = it } > 0) {
                out.write(buf, 0, len)
            }
            out.close()
            `in`.close()
            pfd.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            context.contentResolver.update(uriSavedVideo!!, values, null, null)
        }
    }
}